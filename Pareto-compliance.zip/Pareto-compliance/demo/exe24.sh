#/bin/bash

DIM=(2 3 4 5)
MOP=(LAME MIRROR)
DIFF=(0 1 2)


for m in ${DIM[*]}
do
	for d in ${DIFF[*]}
	do
		printf -v cfgFile "./cfg/Param_%.2dD_2.00_d%d.cfg" "$m" "$d"
		for problem in ${MOP[*]}
		do
			./ibmoea $cfgFile $problem 20 IGD
		done
	done
done