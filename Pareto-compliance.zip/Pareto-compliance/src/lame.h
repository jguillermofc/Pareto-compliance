#ifndef _LS_H
#define _LS_H




double (*g_func)(double);
double gamma_ls;

double EMO_LAME_natmin(double r);
double EMO_LS_ed2(double r);

void LS_init(int g_value, double gamma_value);
void LAME(double *x, double *F, int n, int k, int *feval);
void MIRROR(double *x, double *F, int n, int k, int *feval);

#endif
