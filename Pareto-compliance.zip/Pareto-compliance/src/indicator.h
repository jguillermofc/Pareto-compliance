#ifndef _INDICATOR_H
#define _INDICATOR_H

#include "hv_wfg.h"
#include "utility.h"

typedef struct EMO_IC{
	double v_best;
	int index_best;
	double v_second;
	int index_second;
}EMO_IC;

typedef struct 
{
	double *C;
	EMO_IC *memoization;
}IC;

typedef struct{
	double *W;
	int wsize;
	double *cr2;
	UTILITY utl;
	EMO_IC *memoization;
}R2_contribution;

typedef struct 
{
	double p;
	double *cdeltap;
	double *gd_c;
  	double *D;
	EMO_IC *igd_c;
}DELTAp_contribution;

typedef struct 
{
	EMO_HV hv;
	double *chv;
	double *ref;
}HV_contribution;

typedef struct
{
	double *csenergy;
	double *memoization;
}S_ENERGY_contribution;


// INDICATOR CONTRIBUTIONS 
double EMO_Indicator_r2_moea(double *data, int *filter, int size, double *W, int wsize, UTILITY *utl, EMO_IC *r2_c);
double EMO_Indicator_r2_contribution(double *cr2, double *data, int *enable, int n, double *W, int wsize, UTILITY *utl, EMO_IC *r2_c);
double EMO_Indicator_r2_contribution_pcui(double *cr2, double *data, int *enable, int n, double *W, int wsize, UTILITY *utl, EMO_IC *r2_c);

double EMO_Indicator_epsilon_additive_moea(double *a, int *filter, int na, double *b, int nb, int dim, EMO_IC *epsadd_c);
double EMO_Indicator_epsilon_additive_contribution(double *cepsadd, double *A, int *enable, int n, double *Z, int m, int dim, EMO_IC *epsadd_c);
double EMO_Indicator_epsilon_additive(double *a, int na, int *enableA, double *b, int nb, int *enableB, int dim);
double EMO_Indicator_epsilon_additive_pcui(double *a, int na, double *b, int nb, int dim);
double EMO_Indicator_epsilon_additive_contribution_pcui(double *cepsadd, double *A, int *enable, int n, double *Z, int m, int dim, EMO_IC *epsadd_c);


double mindist_plus_moea(double *v, double *f, int *filter, int n, int dim, EMO_IC *igdplus_mem);
double EMO_Indicator_igd_plus_moea(double *f, int *filter, int n, double *pf, int m, int dim, EMO_IC *igdplus_mem);
double EMO_Indicator_igd_plus_contribution(double *cigdplus, double *A, int *filter, int n, double *Z, int m, int dim, EMO_IC *igdplus_mem);
double EMO_Indicator_igd_plus_contribution_pcui(double *cigdplus, double *A, int *filter, int n, double *Z, int m, int dim, EMO_IC *igdplus_mem);

double EMO_Indicator_gd_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, double *gd_c, double *D);
double EMO_Indicator_gd_contribution(double *cgd, double *f, int *filter, int n, double *pf, int m, int dim, double p, double *gd_c, double *D);
double EMO_Indicator_igd_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *D);
double EMO_Indicator_igd_contribution(double *cigd, double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *D);

double EMO_Indicator_gdp_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, double *gd_c, double *D);
double EMO_Indicator_igdp_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *D);
double EMO_Indicator_deltap_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *gd_c, double *D);
double EMO_Indicator_deltap_contribution(double *cdeltap, double *A, int *enable, int n, double *Z, int m, int dim, double p, EMO_IC *igd_c, double *gd_c, double *D);



double EMO_Indicator_s_energy_moea(double *f,  int *filter, int n, double s, int dim, double *s_energy_c);
double EMO_Indicator_s_energy_contribution(double *csenergy, double *f, int *filter, int n, double s, int dim, double *s_energy_c);

double EMO_Indicator_Hausdorff_Distance(double *X, int N, double *Y, int M, int dim);


void allocate_ic(IC *ic, int asize, int zsize);
void free_ic(IC *ic);

void allocate_r2(R2_contribution *r2c, int n, char *weightsFile, char *utl_name);
void free_r2(R2_contribution *r2c);

void allocate_hv(HV_contribution *hvc, int n, int nobj);
void free_hv(HV_contribution *hvc);

void allocate_deltap(DELTAp_contribution *dpc, int asize, int zsize, double p);
void free_deltap(DELTAp_contribution *dpc);

int findMax(double *data, int size, int *filter);
int findMin(double *data, int size, int *filter);


double EMO_Indicator_deltap(double *f, int *filter, int n, double *pf, int m, int dim, double p);
double EMO_Indicator_igd(double *f, int *filter, int n, double *pf, int m, int dim, double p);
double EMO_Indicator_gd(double *f, int *filter, int n, double *pf, int m, int dim, double p);
double EMO_Indicator_r2(double *data, int *filter, int size, double *W, int wsize, UTILITY *utl);
double EMO_Indicator_igd_plus(double *f, int *filter, int n, double *pf, int m, int dim);
double EMO_Indicator_solow_polasky(double *f, int *filter, int n, int dim);
double EMO_Indicator_senergy(double *f, int *filter, int n, int dim);

double EMO_Indicator_PD(double *A,  int N, int dim);

#endif
