#include "Parameter.h"
#include "ib_moea.h"
#include "evoperators.h"
#include "sort.h"
#include "io.h"

#include <stdio.h>
#include <stdlib.h>



void IB_MOEA_loadParam(IB_MOEA *ibmoea, int nvar){
	getInt("psize", &ibmoea->mu);
	getDouble("pc", &ibmoea->pc);
	getDouble("pm", &ibmoea->pm);
	if(ibmoea->pm == -1.0)
		ibmoea->pm = 1.0/(double)nvar;
	getInt("nc", &ibmoea->Nc);
	getInt("nm", &ibmoea->Nm);
	getInt("feval", &ibmoea->maxFeval);
}

void IB_MOEA_allocate(IB_MOEA *ibmoea, int nvar, int nobj, char *QI, char *param_name){
	char *str;
	str = (char *) malloc(100 * sizeof(char));
	// Read parameters of IB-MOEA
	IB_MOEA_loadParam(ibmoea, nvar);
	// Set internal values 
	ibmoea->lambda = 1;							// Steady-state selection
	ibmoea->N = ibmoea->mu + ibmoea->lambda;	// (mu + 1)-selection scheme
	ibmoea->zsize = ibmoea->mu;					// At most the referece set is of size mu + 1	
	// Allocate seeds from file
	getString("fseed", &str);
	EMO_Rand_alloc_from_file(&ibmoea->rnd, str, 0);
	// Allocate memory for nondominated sorting algorithm
	M3_alloc(&ibmoea->m3nd, ibmoea->N);
	// Allocate memory for internal variables
	if((ibmoea->zmin = (double *) malloc(nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((ibmoea->zmax = (double *) malloc(nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((ibmoea->Z = (double *) malloc(ibmoea->zsize * nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((ibmoea->filter = (int *) malloc(ibmoea->N * sizeof(int))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}	


	Archive_allocate(&ibmoea->arch, nvar, nobj, ibmoea->mu, ibmoea->lambda);

	// Initialize Indicator-based Density Estimators

	if(strcmp(QI, "HV") == 0){
		ibmoea->QIcode = HV;
		allocate_hv(&ibmoea->hv_DE, ibmoea->N, nobj);
	}else if(strcmp(QI, "R2") == 0){
		char *wfile, *utl_name;
		wfile = (char *) malloc(500 * sizeof(char));
		utl_name = (char *) malloc(500 * sizeof(char));
		getString("wfile", &wfile);
		getString("utl_name", &utl_name);

		ibmoea->QIcode = R2;
		allocate_r2(&ibmoea->r2_DE, ibmoea->N, wfile, utl_name);
		free(wfile);
		free(utl_name);
	}else if(strcmp(QI, "IGD+") == 0){
		ibmoea->QIcode = IGDplus;
		allocate_ic(&ibmoea->igdplus_DE, ibmoea->N, ibmoea->arch.Amax);
	}else if(strcmp(QI, "EPS+") == 0){
		ibmoea->QIcode = EPSplus;
		allocate_ic(&ibmoea->epsplus_DE, ibmoea->N, ibmoea->arch.Amax);
	}else if(strcmp(QI, "DELTAp") == 0){
		double p;
		getDouble("p_delta", &p);
		ibmoea->QIcode = DELTAp;
		allocate_deltap(&ibmoea->dp_DE, ibmoea->N, ibmoea->arch.Amax, p);
	}else if(strcmp(QI, "IGD") == 0){
		double p;
		getDouble("p_delta", &p);
		ibmoea->QIcode = IGD;
		allocate_deltap(&ibmoea->dp_DE, ibmoea->N, ibmoea->arch.Amax, p);
	}else if(strcmp(QI, "GD") == 0){
		double p;
		getDouble("p_delta", &p);
		ibmoea->QIcode = GD;
		allocate_deltap(&ibmoea->dp_DE, ibmoea->N, ibmoea->arch.Amax, p);
	}else if(strcmp(QI, "R2++") == 0){
		// Structures for Hypervolume
		ibmoea->QIcode = R2plusplus;
		allocate_hv(&ibmoea->hv_DE, ibmoea->N, nobj);
		// Structures for R2
		char *wfile, *utl_name, *utl_comb;
		wfile = (char *) malloc(500 * sizeof(char));
		utl_name = (char *) malloc(500 * sizeof(char));
		utl_comb = (char *) malloc(500 * sizeof(char));
		getString("wfile", &wfile);
		getString("utl_name", &utl_name);
		getString("utl_comb", &utl_comb);		
		allocate_r2(&ibmoea->r2_DE, ibmoea->N, wfile, utl_name);		
		// Allocate memory for EMOPCUI structure
		EMOPCUI_allocate(&ibmoea->pcui, R2, utl_comb, ibmoea->N);

		free(wfile);
		free(utl_name);
		free(utl_comb);
	}else if(strcmp(QI, "IGD++") == 0){
		char *utl_comb;
		utl_comb = (char *) malloc(500 * sizeof(char));
		getString("utl_comb", &utl_comb);
		// Structures for Hypervolume
		ibmoea->QIcode = IGDplusplus;
		allocate_hv(&ibmoea->hv_DE, ibmoea->N, nobj);
		// Structures for IGD+		
		allocate_ic(&ibmoea->igdplus_DE, ibmoea->N, ibmoea->arch.Amax);
		// Allocate memory for EMOPCUI structure
		EMOPCUI_allocate(&ibmoea->pcui, IGDplus, utl_comb, ibmoea->N);
		free(utl_comb);
	}else if(strcmp(QI, "EPS++") == 0){
		char *utl_comb;
		utl_comb = (char *) malloc(500 * sizeof(char));
		getString("utl_comb", &utl_comb);
		// Structures for Hypervolume
		ibmoea->QIcode = EPSplusplus;
		allocate_hv(&ibmoea->hv_DE, ibmoea->N, nobj);
		// Structures for EPS
		allocate_ic(&ibmoea->epsplus_DE, ibmoea->N, ibmoea->arch.Amax);
		// Allocate memory for EMOPCUI structure
		EMOPCUI_allocate(&ibmoea->pcui, EPSplus, utl_comb, ibmoea->N);
		free(utl_comb);
	}else{
		printf("Error, IB-DE not found!\n");
		exit(-1);
	}
	
	free(str);
}

void IB_MOEA_free(IB_MOEA *ibmoea){
	free(ibmoea->zmin);
	free(ibmoea->zmax);
	free(ibmoea->filter);
	M3_free(&ibmoea->m3nd);	
	EMO_Rand_free(&ibmoea->rnd);
	free(ibmoea->Z);	
	Archive_free(&ibmoea->arch);
	switch(ibmoea->QIcode){
		case HV:
			free_hv(&ibmoea->hv_DE);
		break;

		case R2:
			free_r2(&ibmoea->r2_DE);
		break;

		case IGDplus:
			free_ic(&ibmoea->igdplus_DE);
		break;

		case EPSplus:		
			free_ic(&ibmoea->epsplus_DE);
		break;

		case DELTAp:
		case IGD:
		case GD:
			free_deltap(&ibmoea->dp_DE);
		break;

		case R2plusplus:
			free_hv(&ibmoea->hv_DE);
			free_r2(&ibmoea->r2_DE);
			EMOPCUI_free(&ibmoea->pcui);
		break;

		case IGDplusplus:
			free_hv(&ibmoea->hv_DE);
			free_ic(&ibmoea->igdplus_DE);
			EMOPCUI_free(&ibmoea->pcui);

		break;

		case EPSplusplus:
			free_hv(&ibmoea->hv_DE);
			free_ic(&ibmoea->epsplus_DE);
			EMOPCUI_free(&ibmoea->pcui);
		break;

	}
}

void IB_MOEA_nextPopulation(IB_MOEA *ibmoea, Population *pop, MOP *mop, int delete){
	int nvar, nobj;
	nvar = mop->nvar;
	nobj = mop->nobj;

	if(delete != ibmoea->N - 1){
		memcpy(&pop->x[delete * nvar], &pop->x[ibmoea->mu * nvar], nvar * sizeof(double));
		memcpy(&pop->F[delete * nobj], &pop->F[ibmoea->mu * nobj], nobj * sizeof(double));
	}
}

void IB_MOEA_random_parent_selection(IB_MOEA *alg, int *p1, int *p2, int nvar){
	*p1 =  EMO_Rand_int1(&alg->rnd, 0, alg->mu - 1);
    while ((*p2 = EMO_Rand_int1(&alg->rnd, 0, alg->mu - 1)) == *p1);
    *p1 *= nvar;
 	*p2 *= nvar;
}

void SSS_executeSSS(IB_MOEA *ibmoea, Population *pop, MOP *mop){
	int i;
	double totalPCUI;

	ibmoea->pcui.I[0] = EMO_HV_contribution_pcui(&ibmoea->hv_DE.hv, ibmoea->hv_DE.chv, pop->Fnorm, ibmoea->filter, ibmoea->N, ibmoea->hv_DE.ref, mop->nobj);	

	switch(ibmoea->pcui.wpcQI){
		case R2:
			ibmoea->pcui.I[1] = EMO_Indicator_r2_contribution_pcui(ibmoea->r2_DE.cr2,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->r2_DE.W,
				ibmoea->r2_DE.wsize,
				&ibmoea->r2_DE.utl,
				ibmoea->r2_DE.memoization);
			
		break;

		case IGDplus:
			ibmoea->pcui.I[1] = EMO_Indicator_igd_plus_contribution_pcui(ibmoea->igdplus_DE.C,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->igdplus_DE.memoization);
			
		break;

		case EPSplus:
			ibmoea->pcui.I[1] = EMO_Indicator_epsilon_additive_contribution_pcui(ibmoea->epsplus_DE.C,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->epsplus_DE.memoization);
			
		break;
	}
 
	// Calculate total value of Pareto compliant utility indicator
	totalPCUI = ibmoea->pcui.utl.uf(&ibmoea->pcui.utl, ibmoea->pcui.I, ibmoea->pcui.w);

	// Compute contributions of the utility indicator
	for(i = 0; i < ibmoea->N; i++){
		if(ibmoea->filter[i]){
			// Fulfill auxiliary vector I
			ibmoea->pcui.I[0] = ibmoea->hv_DE.chv[i];

			switch(ibmoea->pcui.wpcQI){
				case R2:
					ibmoea->pcui.I[1] = ibmoea->r2_DE.cr2[i];
				break;

				case IGDplus:
					ibmoea->pcui.I[1] = ibmoea->igdplus_DE.C[i];
				break;

				case EPSplus:
					ibmoea->pcui.I[1] = ibmoea->epsplus_DE.C[i];
				break;
			}
			// Contribution to the utility indicator associated to the ith individual
			ibmoea->pcui.C[i] = totalPCUI - ibmoea->pcui.utl.uf(&ibmoea->pcui.utl, ibmoea->pcui.I, ibmoea->pcui.w);			
		}else{
			ibmoea->pcui.C[i] = -DBL_MAX;
		}
	}
}

void IB_MOEA_contribution(IB_MOEA *ibmoea, Population *pop, MOP *mop, double **contr){
	int i;
	switch(ibmoea->QIcode){
		case HV:
			//Population_get_nadir(pop, ibmoea->N, ibmoea->hv_DE.ref, mop->nobj);
      		for(i = 0; i < mop->nobj; i++){
      			ibmoea->hv_DE.ref[i] = 1.1; // ATTENTION! IT IS USED THIS WAY BECAUSE WE ARE USING THE NORMALIZED VALUES IN THE NEXT FUNCTION
      		}
			EMO_HV_contribution(&ibmoea->hv_DE.hv,
				ibmoea->hv_DE.chv,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->hv_DE.ref,
				mop->nobj);
			*contr = ibmoea->hv_DE.chv;
		break;

		case R2:
			EMO_Indicator_r2_contribution(ibmoea->r2_DE.cr2,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->r2_DE.W,
				ibmoea->r2_DE.wsize,
				&ibmoea->r2_DE.utl,
				ibmoea->r2_DE.memoization);
			*contr = ibmoea->r2_DE.cr2;
		break;

		case IGDplus:      		
			EMO_Indicator_igd_plus_contribution(ibmoea->igdplus_DE.C,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->igdplus_DE.memoization);
			*contr = ibmoea->igdplus_DE.C;
		break;

		case EPSplus:
			EMO_Indicator_epsilon_additive_contribution(ibmoea->epsplus_DE.C,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->epsplus_DE.memoization);
			*contr = ibmoea->epsplus_DE.C;
		break;

		case DELTAp:
			EMO_Indicator_deltap_contribution(ibmoea->dp_DE.cdeltap,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->dp_DE.p,
				ibmoea->dp_DE.igd_c,
				ibmoea->dp_DE.gd_c,
				ibmoea->dp_DE.D);
			*contr = ibmoea->dp_DE.cdeltap;
		break;

		case IGD:
			EMO_Indicator_igd_contribution(ibmoea->dp_DE.cdeltap,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->dp_DE.p,
				ibmoea->dp_DE.igd_c,
				ibmoea->dp_DE.D);
			*contr = ibmoea->dp_DE.cdeltap;
		break;


		case GD:
			EMO_Indicator_gd_contribution(ibmoea->dp_DE.cdeltap,
				pop->Fnorm,
				ibmoea->filter,
				ibmoea->N,
				ibmoea->Z,
				ibmoea->zsize,
				mop->nobj,
				ibmoea->dp_DE.p,
				ibmoea->dp_DE.gd_c,
				ibmoea->dp_DE.D);
			*contr = ibmoea->dp_DE.cdeltap;
		break;

		case R2plusplus:
		case IGDplusplus:
		case EPSplusplus:
			for(i = 0; i < mop->nobj; i++)
      			ibmoea->hv_DE.ref[i] = 1.1; // ATTENTION! IT IS USED THIS WAY BECAUSE WE ARE USING THE NORMALIZED VALUES IN THE NEXT FUNCTION
      		SSS_executeSSS(ibmoea, pop, mop);
      		*contr = ibmoea->pcui.C;
      	break;
	}
}

int IB_MOEA_densityEstimator(IB_MOEA *ibmoea, Population *pop, MOP *mop){
	int worstContributing;
	double *contr;
	// Compute individual contributions to the specific QI
	IB_MOEA_contribution(ibmoea, pop, mop, &contr);
	// Get worst-contributing solution
	worstContributing = findMin(contr, ibmoea->N, ibmoea->filter);
	return worstContributing;
}

void IB_MOEA_buildReferenceSet(IB_MOEA *alg, Population *pop, MOP *mop, int lastLayer){
	/*
	// Naïve Reference Set
	int i, j, k;
	for(i = 0; i < alg->m3nd.sizeNDFront[0]; i++){
		j = alg->m3nd.NDFront[i];      		
		for(k = 0; k < mop->nobj; k++){
			alg->Z[i * mop->nobj + k] =  pop->Fnorm[j * mop->nobj + k];      			    		
		}
	}
	alg->zsize = alg->m3nd.sizeNDFront[0];*/



	// Construction of reference set using the pair-potential-based archive

	// Normalize archive (using its own reference vectors)
	int i, j;
	double eps;

	Population_get_nadir(&alg->arch.pop, alg->arch.csize, alg->zmax, mop->nobj);
	Population_get_ideal(&alg->arch.pop, alg->arch.csize, alg->zmin, mop->nobj);
	Population_normalize(&alg->arch.pop, alg->arch.csize, alg->zmin, alg->zmax, mop->nobj);


	eps = EMO_Indicator_epsilon_additive(alg->arch.pop.Fnorm, alg->arch.csize, alg->arch.filter,
		pop->Fnorm, alg->m3nd.sizeNDFront[lastLayer], alg->filter, mop->nobj);

	// Traslate reference set
	if(eps > 0.0){
		for(i = 0; i < alg->arch.csize; i++){
			for(j = 0; j < mop->nobj; j++){
				alg->Z[i * mop->nobj + j] = alg->arch.pop.Fnorm[i * mop->nobj + j] - eps;
			}
		}
	}
	alg->zsize = alg->arch.csize;
}

void IB_MOEA_print_results(IB_MOEA *ibmoea, Population *pop, MOP *mop, int exec){
	char filename[500];
	switch(ibmoea->QIcode){
		case HV:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/SMS-EMOA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
				sprintf(filename, "output/SMS-EMOA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case R2:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/R2-EMOA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/R2-EMOA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case IGDplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/IGD+-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/IGD+-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case EPSplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/EPS+-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/EPS+-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case DELTAp:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/DELTAp-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/DELTAp-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case IGD:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/IGD-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/IGD-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case GD:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/GD-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/GD-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;

		case R2plusplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/R2++-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/R2++-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;


		case IGDplusplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/IGD++-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/IGD++-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;


		case EPSplusplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(filename, "output/EPS++-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.pof", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec);
			else
			sprintf(filename, "output/EPS++-MaOEA_%s_%.2dD_R%.2d.pof", mop->mop_name, mop->nobj, exec);
		break;
	}
	print_Data(pop->F, mop->nobj, ibmoea->mu, filename);
}

void IB_MOEA_init(IB_MOEA *ibmoea, Population *pop, MOP *mop){
	int i;
	// Look for next random seed
	EMO_Rand_next_seed(&ibmoea->rnd, 0);
	// Set total number of function evaluations to zero
	mop->feval = 0;
	// Randomly initialize population
	Population_init(pop, &ibmoea->rnd, ibmoea->mu, mop->nvar, mop->xmin, mop->xmax);
	// Evaluate objective functions of all the newly created individuals
	for(i = 0; i < ibmoea->mu; i++){
		MOP_evaluate(mop, pop->x, pop->F, i);
	}
}

void IB_MOEA_run(IB_MOEA *ibmoea, Population *pop, MOP *mop, int exec, MONITOR *monitor){
	printf("Execution %d of IB-MOEA, solving %s %.2dD\n", exec, mop->mop_name, mop->nobj);
	int i, j, p1, p2, lastFront, worstContributing;
	// Set initial condition to execute the IB-MOEA
	IB_MOEA_init(ibmoea, pop, mop);	
	// Initialize archive
	Archive_initialize(&ibmoea->arch, pop, ibmoea->mu, mop->nobj, mop->nvar);
	int generation = 0;
	while(mop->feval < ibmoea->maxFeval){
		// RANDOM PARENT SELECTION 
		IB_MOEA_random_parent_selection(ibmoea, &p1, &p2, mop->nvar);
		// CREATE NEW OFFSPRING 
		crossSBX(&ibmoea->rnd, &pop->x[ibmoea->mu * mop->nvar], pop->dummy, &pop->x[p1], &pop->x[p2], mop, ibmoea->pc, ibmoea->Nc);
		mutatePolynom(&ibmoea->rnd, &pop->x[ibmoea->mu * mop->nvar], mop, ibmoea->pm, ibmoea->Nm);
		MOP_evaluate(mop, pop->x, pop->F, ibmoea->mu);
		// INSERT NEWLY CREATED SOLUTION IN THE ARCHIVE
		Archive_insert(&ibmoea->arch, &pop->x[ibmoea->mu * mop->nvar], &pop->F[ibmoea->mu * mop->nobj], mop->nvar, mop->nobj);
		Archive_PairPotential_prunning(&ibmoea->arch, ibmoea->zmin, ibmoea->zmax, mop->nvar, mop->nobj);

		// EXECUTE NONDOMINATED SORTING
      	memset(ibmoea->filter, 1, ibmoea->N * sizeof(int));
      	M3NDsorting_execute(&ibmoea->m3nd, pop->F, ibmoea->filter, ibmoea->N, mop->nobj); 
      	lastFront = ibmoea->m3nd.numFronts - 1;

      	// GET DATA TO MONITOR
      	MONITOR_set_num_nondominated_solutions(monitor, ibmoea->m3nd.sizeNDFront[0], generation);
		MONITOR_set_num_layers(monitor, ibmoea->m3nd.numFronts, generation);

      	if(ibmoea->m3nd.sizeNDFront[lastFront] > 1){
      		// GET DATA TO MONITOR
      		MONITOR_set_activation(monitor, 1, generation);
      		// NORMALIZE POPULATION       		
      		Population_get_nadir(pop, ibmoea->N, ibmoea->zmax, mop->nobj);
			Population_get_ideal(pop, ibmoea->N, ibmoea->zmin, mop->nobj);
      		Population_normalize(pop, ibmoea->N, ibmoea->zmin, ibmoea->zmax, mop->nobj);
      		// ACTIVATE THOSE INDIVIDUALS BELONGGING TO THE LAST FRONT
      		memset(ibmoea->filter, 0, ibmoea->N * sizeof(int));
      		for(i = 0; i < ibmoea->m3nd.sizeNDFront[lastFront]; i++){
      			j = ibmoea->m3nd.NDFront[lastFront * ibmoea->N + i];
      			ibmoea->filter[j] = 1;
      		}
      		IB_MOEA_buildReferenceSet(ibmoea, pop, mop, lastFront);
      		// EXECUTE INDICATOR-BASED DENSITY ESTIMATOR
      		worstContributing = IB_MOEA_densityEstimator(ibmoea, pop, mop);
      	}else{
      		// DEACTIVATE THE SOLE INDIVIDUAL IN THE LAST FRONT
      		worstContributing = ibmoea->m3nd.NDFront[lastFront * ibmoea->N];  
      		// GET DATA TO MONITOR
      		MONITOR_set_activation(monitor, 0, generation);
      	}
      	// CREATE NEXT POPULATON BY DELETING THE SELECTED SOLUTION      	
      	IB_MOEA_nextPopulation(ibmoea, pop, mop, worstContributing);

      	// GET DATA TO MONITOR
      	MONITOR_assessment(monitor, pop, ibmoea->mu, mop->nobj, generation);

      	generation++;
      	MONITOR_adjust_counter(monitor, generation);
	}
	IB_MOEA_print_results(ibmoea, pop, mop, exec);

	// PRINT MONITOR DATA
	MONITOR_print_results(monitor, mop, ibmoea->QIcode, exec);

}