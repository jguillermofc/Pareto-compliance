#ifndef _MONITOR_H_
#define _MONITOR_H_

#include "indicator.h"
#include "hv_wfg.h"
#include "population.h"
#include "mop.h"
#include "utility.h"
#include "M3.h"




typedef  struct 
{
	// Shared structures
	EMO_HV hv;
	double *zref;
	int samples_number;
	int counter;
	int freq;

	// Behavior plots
	double *hv_samples;			// Convergence samples
	double *pd_samples;			// Diversity samples

	// Caracterization of IB-DE
	int *num_nondominated_solutions;
	int *activation_ib_de;
	int *num_layers;	

	char *fname;

	
}MONITOR;

void MONITOR_allocate(MONITOR *monitor, int nobj, int mu, int Gmax);
void MONITOR_free(MONITOR *monitor);
void MONITOR_initialize(MONITOR *monitor);
void MONITOR_adjust_counter(MONITOR *monitor, int generation);
void MONITOR_assessment(MONITOR *monitor, Population *pop, int mu, int nobj, int generation);
void MONITOR_set_num_nondominated_solutions(MONITOR *monitor, int number, int generation);
void MONITOR_set_activation(MONITOR *monitor, int wasActivated, int generation);
void MONITOR_set_num_layers(MONITOR *monitor, int number, int generation);

void MONITOR_print_results(MONITOR *monitor, MOP *mop, int QIcode, int exec);
void MONITOR_set_reference_point(MONITOR *monitor, char *mop_name, int nobj);




#endif
