#ifndef __IO_H__
#define __IO_H__

double *readFile(double *data, int *row, int *col, const char *str, int start);
void print_Data(double *data, int n, int size, char *filename);

#endif