#include "M3.h"

void M3_alloc(M3NDsorting *m3nd, int N){
	if((m3nd->Min = (int *)malloc(N * sizeof(int))) == NULL){
		printf("Error, not enough memory for Min in NSGA3\n");
		exit(1);
	}

	if((m3nd->rank = (int *)malloc(N * sizeof(int))) == NULL){
		printf("Error, not enough memory for rank in NSGA3\n");
		exit(1);
	}

	if((m3nd->NDFront = (int *)malloc(N * N * sizeof(int))) == NULL){
		printf("Error, not enough memory for NDFront in NSGA3\n");
		exit(1);
	}

	if((m3nd->sizeNDFront = (int *)malloc(N * sizeof(int))) == NULL){
		printf("Error, not enough memory for NDFront in NSGA3\n");
		exit(1);
	}
}

void M3_free(M3NDsorting *m3nd){
	free(m3nd->Min);
	free(m3nd->rank);
	free(m3nd->NDFront);
	free(m3nd->sizeNDFront);
}

int haveAllBeenRanked(int *filter, int N, int *start){
	int i;
	for(i = 0; i < N; i++){
		if(filter[i]){
			*start = i;
			return 0;
		}
	}
	return 1;
}

void M3NDsorting_execute(M3NDsorting *m3nd, double *S, int *filter, int N, int dim){
	m3nd->numFronts = 0;
	int start, i, front = 0;
	while(!haveAllBeenRanked(filter, N, &start)){
		m3nd->sizeNDFront[front] = 0; 
		M3(m3nd, S, filter, N, dim, start);
		for(i = 0; i < m3nd->TopMin; i++){
			m3nd->rank[m3nd->Min[i]] = front;
			filter[m3nd->Min[i]] = 0;
			m3nd->NDFront[front*N + m3nd->sizeNDFront[front]] = m3nd->Min[i];
			m3nd->sizeNDFront[front]++;
		}
		front++;
	}
	m3nd->numFronts = front;
}


void M3(M3NDsorting *m3nd, double *S, int *filter, int N, int dim, int start){
	m3nd->TopMin = 0;
	m3nd->Min[m3nd->TopMin] = start;
	m3nd->TopMin = 1;
	int i, j, val;
	for(i = start + 1; i < N; i++){
		if(filter[i]){
			j = 0;
			while(j < m3nd->TopMin){
				val = ParetoDominance(&S[m3nd->Min[j] * dim], &S[i * dim], dim);
				if(val == 1){
					moveToFront(m3nd->Min, j, m3nd->TopMin);
					j = m3nd->TopMin + 1;
				}else if(val == -1){
					shift(m3nd->Min, j, m3nd->TopMin);
					m3nd->TopMin--;
				}else if(val == 2){
					j = m3nd->TopMin + 1;
				}else if(val == 0){
					j++;
				}
			}
			if(j == m3nd->TopMin){
				m3nd->TopMin++;
				m3nd->Min[m3nd->TopMin - 1] = i;
			}
		}
	}
}



void moveToFront(int *T, int j, int size){
	int i, aux1, aux2;
	aux1 = T[0];
	for(i = 0; i < j; i++){		
		aux2 = T[(i + 1) % (j + 1)];
		T[(i + 1) % (j + 1)] = aux1;
		aux1 = aux2;
	}
}

void shift(int *T, int j, int size){
	int i;
	for(i = j + 1; i < size; i++){
		if(i - 1 < 0){
			printf("Error en shift\n");
			exit(-1);
		}
		T[i - 1] = T[i];
	}
}

/* ParetoDominance 
 *
 * A solution x strictly dominates a solution y, iff
 * x[i] <= y[i] for all i in {1,..,n} and x[j] < y[j] for at least one j in {1,..,n}.
 *
 * Return value: 
 *  1 - if x dominates y
 *  0 - if x and y are mutually non dominated  (INCOMPARABLE)
 * -1 - if y dominates x
 *  2 - if x and y are equal
 */
int ParetoDominance(double *x, double *y, int n) {
  int i, fx, fy, eq;

  fx = fy = eq = 0;

  for(i = 0; i < n; i++) {
    if(x[i] < y[i])
      fx++;
    else if(x[i] > y[i])
      fy++;
    else
      eq++;
  }

  if(fx > 0 && fy == 0)
    return 1;

  if(fy > 0 && fx == 0)
    return -1;

  if(eq == n)
    return 2;

  return 0;
}
