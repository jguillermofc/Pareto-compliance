#ifndef __MOP_H__
#define __MOP_H__

typedef struct{
	void (*F)(double *, double *, int, int, int *);		// Pointer to objective function 
	int nvar;					// Number of decision variables.
	int nobj;					// Number of objective vectors.
	int feval;					// Function evaluations counter.
	char *mop_name;				// MOP name.
	double *xmax;				// upper bounds of the decision variables.
	double *xmin;				// lower bounds of the decision variables.
	int k_wfg;					// number of position related parameters for WFG problems.
	int isLame;
	double gamma_value;
	int lame_difficulty;
}MOP;

void MOP_allocate(MOP *, char *);
void MOP_free(MOP *);
void MOP_evaluate(MOP *mop, double *x, double *F, int index);

#endif