
#ifndef _ARCHIVE_H
#define _ARCHIVE_H

#include "potentials.h"
#include "population.h"



typedef struct
{
	int Amax;				// Maximum archive size
	int vsize;				// Virtual size (i.e.,  Amax + N, where N is the number of extra slots)
	int csize;				// Current archive size
	int *filter;			// Indicates the active solutions
	PP_contribution ppc;	// Structute for the contribution to the pair potential functions
	Population pop;			// Population structure
}Archive;


void Archive_initialize(Archive *arch, Population *pop, int mu, int nobj, int nvar);
void Archive_allocate(Archive *arch, int nvar, int nobj, int mu, int lambda);
void Archive_free(Archive *arch);
void Archive_insert(Archive *arch, double *x, double *F, int nvar, int nobj);
void Archive_exchange(Archive *arch, int nvar, int nobj);
void Archive_PairPotential_prunning(Archive *arch, double *zmin, double *zmax, int nvar, int nobj);
#endif