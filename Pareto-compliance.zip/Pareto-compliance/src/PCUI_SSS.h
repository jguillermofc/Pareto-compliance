
#ifndef __SSS_H__
#define __SSS_H__

#include "utility.h"
#include "indicator.h"



typedef struct EMOPCUI{
	UTILITY utl;		/* Order-preserving utility/combination function */
	double w[2];				/* weight vector for the combination */
	double I[2];				/* Auxiliary vector to store the total indicator values */
	double *C;				/* Array of individual contributions */
	int wpcQI;				/* Names of the indicators to be combined */
}EMOPCUI;

void EMOPCUI_allocate(EMOPCUI *pcui, int wpcQI, char *utl_name, int N);
void EMOPCUI_free(EMOPCUI *pcui);

#endif