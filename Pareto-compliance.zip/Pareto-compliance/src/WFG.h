#ifndef __WFG_H__
#define __WFG_H__

#include <stdlib.h>
#include <math.h>

#define max(A,B) ((A)>(B) ? (A) : (B)) 
#define min(A,B) ((A)<(B) ? (A) : (B)) 
#define PI 3.1415926535897932384626433832795

double *zmax;
double *t;
double *x;
double *h;
double *S;
double *A;
double *y;
double *w;
int k_wfg;

void print_vec(char *s, double *v, int n);

/* Shapes */
double sh_linear_1(double *x, int M);
double sh_linear_m(double *x, int M, int m);
double sh_linear_M(double *x);
void sh_linear(double **h, double *x, int M); 
double sh_convex_1(double *x, int M);
double sh_convex_m(double *x, int M, int m);
double sh_convex_M(double *x);
void sh_convex(double **h, double *x, int M); 
double sh_concave_1(double *x, int M);
double sh_concave_m(double *x, int M, int m);
double sh_concave_M(double *x);
void sh_concave(double **h, double *x, int M); 
double sh_mixed_M(double *x, double A, double alpha);
double sh_disc_M(double *x, double A, double alpha, double beta);

/* Transformations */
double tr_b_poly(double y, double alpha);
double tr_b_flat(double y, double A, double B, double C);
double tr_b_param(double y, double u, double A, double B, double C);
double tr_s_linear(double y, double A);
double tr_s_decept(double y, double A, double B, double C);
double tr_s_multi(double y, double A, double B, double C);
double tr_r_sum(double *y, double *w, int n);
double tr_r_nonsep(double *y, double A, int n);

/* Transformations per function */
void wfg1_t1(double **t, double *z, int N, int K); 
void wfg1_t2(double **t, double *z, int N, int K); 
void wfg1_t3(double **t, double *z, int N); 
void wfg1_t4(double **t, double *z, int M, int N, int K); 
void wfg2_t2(double **t, double *z, int N, int K); 
void wfg2_t3(double **t, double *z, int M, int N, int K); 
void wfg4_t1(double **t, double *z, int N); 
void wfg4_t2(double **t, double *z, int M, int N, int K); 
void wfg5_t1(double **t, double *z, int N); 
void wfg6_t2(double **t, double *z, int M, int N, int K); 
void wfg7_t1(double **t, double *z, int N, int K); 
void wfg8_t1(double **t, double *z, int N, int K);
void wfg9_t1(double **t, double *z, int N); 
void wfg9_t2(double **t, double *z, int N, int K); 

void calc_x(double **x, double *t, double *A, int M); 
void calc_f(double **f, double *x, double *S, double *h, int M); 

/* WFG test suite */
void wfg1(double *z, double *F, int n, int k, int *feval);
void wfg2(double *z, double *F, int n, int k, int *feval);
void wfg3(double *z, double *F, int n, int k, int *feval);
void wfg4(double *z, double *F, int n, int k, int *feval);
void wfg5(double *z, double *F, int n, int k, int *feval);
void wfg6(double *z, double *F, int n, int k, int *feval);
void wfg7(double *z, double *F, int n, int k, int *feval);
void wfg8(double *z, double *F, int n, int k, int *feval);
void wfg9(double *z, double *F, int n, int k, int *feval);


void wfg1_minus(double *z, double *F, int n, int k, int *feval);
void wfg2_minus(double *z, double *F, int n, int k, int *feval);
void wfg3_minus(double *z, double *F, int n, int k, int *feval);
void wfg4_minus(double *z, double *F, int n, int k, int *feval);
void wfg5_minus(double *z, double *F, int n, int k, int *feval);
void wfg6_minus(double *z, double *F, int n, int k, int *feval);
void wfg7_minus(double *z, double *F, int n, int k, int *feval);
void wfg8_minus(double *z, double *F, int n, int k, int *feval);
void wfg9_minus(double *z, double *F, int n, int k, int *feval);



void wfg1_UNS(double *z, double *F, int n, int k, int *feval);
void wfg1_UNN(double *z, double *F, int n, int k, int *feval);
void wfg1_UPS(double *z, double *F, int n, int k, int *feval);
void wfg1_UPN(double *z, double *F, int n, int k, int *feval);
void wfg1_UFS(double *z, double *F, int n, int k, int *feval);
void wfg1_UFN(double *z, double *F, int n, int k, int *feval);
void wfg1_UDS(double *z, double *F, int n, int k, int *feval);
void wfg1_UDN(double *z, double *F, int n, int k, int *feval);

void wfg1_MNS(double *z, double *F, int n, int k, int *feval);
void wfg1_MNN(double *z, double *F, int n, int k, int *feval);
void wfg1_MPS(double *z, double *F, int n, int k, int *feval);
void wfg1_MPN(double *z, double *F, int n, int k, int *feval);
void wfg1_MFS(double *z, double *F, int n, int k, int *feval);
void wfg1_MFN(double *z, double *F, int n, int k, int *feval);
void wfg1_MDS(double *z, double *F, int n, int k, int *feval);
void wfg1_MDN(double *z, double *F, int n, int k, int *feval);

void wfg1_DNS(double *z, double *F, int n, int k, int *feval);
void wfg1_DNN(double *z, double *F, int n, int k, int *feval);
void wfg1_DPS(double *z, double *F, int n, int k, int *feval);
void wfg1_DPN(double *z, double *F, int n, int k, int *feval);
void wfg1_DFS(double *z, double *F, int n, int k, int *feval);
void wfg1_DFN(double *z, double *F, int n, int k, int *feval);
void wfg1_DDS(double *z, double *F, int n, int k, int *feval);
void wfg1_DDN(double *z, double *F, int n, int k, int *feval);



void wfg2_UNS(double *z, double *F, int n, int k, int *feval);
void wfg2_UNN(double *z, double *F, int n, int k, int *feval);
void wfg2_UPS(double *z, double *F, int n, int k, int *feval);
void wfg2_UPN(double *z, double *F, int n, int k, int *feval);
void wfg2_UFS(double *z, double *F, int n, int k, int *feval);
void wfg2_UFN(double *z, double *F, int n, int k, int *feval);
void wfg2_UDS(double *z, double *F, int n, int k, int *feval);
void wfg2_UDN(double *z, double *F, int n, int k, int *feval);

void wfg2_MNS(double *z, double *F, int n, int k, int *feval);
void wfg2_MNN(double *z, double *F, int n, int k, int *feval);
void wfg2_MPS(double *z, double *F, int n, int k, int *feval);
void wfg2_MPN(double *z, double *F, int n, int k, int *feval);
void wfg2_MFS(double *z, double *F, int n, int k, int *feval);
void wfg2_MFN(double *z, double *F, int n, int k, int *feval);
void wfg2_MDS(double *z, double *F, int n, int k, int *feval);
void wfg2_MDN(double *z, double *F, int n, int k, int *feval);

void wfg2_DNS(double *z, double *F, int n, int k, int *feval);
void wfg2_DNN(double *z, double *F, int n, int k, int *feval);
void wfg2_DPS(double *z, double *F, int n, int k, int *feval);
void wfg2_DPN(double *z, double *F, int n, int k, int *feval);
void wfg2_DFS(double *z, double *F, int n, int k, int *feval);
void wfg2_DFN(double *z, double *F, int n, int k, int *feval);
void wfg2_DDS(double *z, double *F, int n, int k, int *feval);
void wfg2_DDN(double *z, double *F, int n, int k, int *feval);



void wfg3_UNS(double *z, double *F, int n, int k, int *feval);
void wfg3_UNN(double *z, double *F, int n, int k, int *feval);
void wfg3_UPS(double *z, double *F, int n, int k, int *feval);
void wfg3_UPN(double *z, double *F, int n, int k, int *feval);
void wfg3_UFS(double *z, double *F, int n, int k, int *feval);
void wfg3_UFN(double *z, double *F, int n, int k, int *feval);
void wfg3_UDS(double *z, double *F, int n, int k, int *feval);
void wfg3_UDN(double *z, double *F, int n, int k, int *feval);

void wfg3_MNS(double *z, double *F, int n, int k, int *feval);
void wfg3_MNN(double *z, double *F, int n, int k, int *feval);
void wfg3_MPS(double *z, double *F, int n, int k, int *feval);
void wfg3_MPN(double *z, double *F, int n, int k, int *feval);
void wfg3_MFS(double *z, double *F, int n, int k, int *feval);
void wfg3_MFN(double *z, double *F, int n, int k, int *feval);
void wfg3_MDS(double *z, double *F, int n, int k, int *feval);
void wfg3_MDN(double *z, double *F, int n, int k, int *feval);

void wfg3_DNS(double *z, double *F, int n, int k, int *feval);
void wfg3_DNN(double *z, double *F, int n, int k, int *feval);
void wfg3_DPS(double *z, double *F, int n, int k, int *feval);
void wfg3_DPN(double *z, double *F, int n, int k, int *feval);
void wfg3_DFS(double *z, double *F, int n, int k, int *feval);
void wfg3_DFN(double *z, double *F, int n, int k, int *feval);
void wfg3_DDS(double *z, double *F, int n, int k, int *feval);
void wfg3_DDN(double *z, double *F, int n, int k, int *feval);



void wfg4_UNS(double *z, double *F, int n, int k, int *feval);
void wfg4_UNN(double *z, double *F, int n, int k, int *feval);
void wfg4_UPS(double *z, double *F, int n, int k, int *feval);
void wfg4_UPN(double *z, double *F, int n, int k, int *feval);
void wfg4_UFS(double *z, double *F, int n, int k, int *feval);
void wfg4_UFN(double *z, double *F, int n, int k, int *feval);
void wfg4_UDS(double *z, double *F, int n, int k, int *feval);
void wfg4_UDN(double *z, double *F, int n, int k, int *feval);

void wfg4_MNS(double *z, double *F, int n, int k, int *feval);
void wfg4_MNN(double *z, double *F, int n, int k, int *feval);
void wfg4_MPS(double *z, double *F, int n, int k, int *feval);
void wfg4_MPN(double *z, double *F, int n, int k, int *feval);
void wfg4_MFS(double *z, double *F, int n, int k, int *feval);
void wfg4_MFN(double *z, double *F, int n, int k, int *feval);
void wfg4_MDS(double *z, double *F, int n, int k, int *feval);
void wfg4_MDN(double *z, double *F, int n, int k, int *feval);

void wfg4_DNS(double *z, double *F, int n, int k, int *feval);
void wfg4_DNN(double *z, double *F, int n, int k, int *feval);
void wfg4_DPS(double *z, double *F, int n, int k, int *feval);
void wfg4_DPN(double *z, double *F, int n, int k, int *feval);
void wfg4_DFS(double *z, double *F, int n, int k, int *feval);
void wfg4_DFN(double *z, double *F, int n, int k, int *feval);
void wfg4_DDS(double *z, double *F, int n, int k, int *feval);
void wfg4_DDN(double *z, double *F, int n, int k, int *feval);



void wfg5_UNS(double *z, double *F, int n, int k, int *feval);
void wfg5_UNN(double *z, double *F, int n, int k, int *feval);
void wfg5_UPS(double *z, double *F, int n, int k, int *feval);
void wfg5_UPN(double *z, double *F, int n, int k, int *feval);
void wfg5_UFS(double *z, double *F, int n, int k, int *feval);
void wfg5_UFN(double *z, double *F, int n, int k, int *feval);
void wfg5_UDS(double *z, double *F, int n, int k, int *feval);
void wfg5_UDN(double *z, double *F, int n, int k, int *feval);

void wfg5_MNS(double *z, double *F, int n, int k, int *feval);
void wfg5_MNN(double *z, double *F, int n, int k, int *feval);
void wfg5_MPS(double *z, double *F, int n, int k, int *feval);
void wfg5_MPN(double *z, double *F, int n, int k, int *feval);
void wfg5_MFS(double *z, double *F, int n, int k, int *feval);
void wfg5_MFN(double *z, double *F, int n, int k, int *feval);
void wfg5_MDS(double *z, double *F, int n, int k, int *feval);
void wfg5_MDN(double *z, double *F, int n, int k, int *feval);

void wfg5_DNS(double *z, double *F, int n, int k, int *feval);
void wfg5_DNN(double *z, double *F, int n, int k, int *feval);
void wfg5_DPS(double *z, double *F, int n, int k, int *feval);
void wfg5_DPN(double *z, double *F, int n, int k, int *feval);
void wfg5_DFS(double *z, double *F, int n, int k, int *feval);
void wfg5_DFN(double *z, double *F, int n, int k, int *feval);
void wfg5_DDS(double *z, double *F, int n, int k, int *feval);
void wfg5_DDN(double *z, double *F, int n, int k, int *feval);


void wfg6_UNS(double *z, double *F, int n, int k, int *feval);
void wfg6_UNN(double *z, double *F, int n, int k, int *feval);
void wfg6_UPS(double *z, double *F, int n, int k, int *feval);
void wfg6_UPN(double *z, double *F, int n, int k, int *feval);
void wfg6_UFS(double *z, double *F, int n, int k, int *feval);
void wfg6_UFN(double *z, double *F, int n, int k, int *feval);
void wfg6_UDS(double *z, double *F, int n, int k, int *feval);
void wfg6_UDN(double *z, double *F, int n, int k, int *feval);

void wfg6_MNS(double *z, double *F, int n, int k, int *feval);
void wfg6_MNN(double *z, double *F, int n, int k, int *feval);
void wfg6_MPS(double *z, double *F, int n, int k, int *feval);
void wfg6_MPN(double *z, double *F, int n, int k, int *feval);
void wfg6_MFS(double *z, double *F, int n, int k, int *feval);
void wfg6_MFN(double *z, double *F, int n, int k, int *feval);
void wfg6_MDS(double *z, double *F, int n, int k, int *feval);
void wfg6_MDN(double *z, double *F, int n, int k, int *feval);

void wfg6_DNS(double *z, double *F, int n, int k, int *feval);
void wfg6_DNN(double *z, double *F, int n, int k, int *feval);
void wfg6_DPS(double *z, double *F, int n, int k, int *feval);
void wfg6_DPN(double *z, double *F, int n, int k, int *feval);
void wfg6_DFS(double *z, double *F, int n, int k, int *feval);
void wfg6_DFN(double *z, double *F, int n, int k, int *feval);
void wfg6_DDS(double *z, double *F, int n, int k, int *feval);
void wfg6_DDN(double *z, double *F, int n, int k, int *feval);


void init_WFG(int wfg, int M, int N, int K);
void free_WFG(); 

#endif
