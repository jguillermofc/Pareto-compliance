#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <math.h>
double minkowski_distance(double *x, double *y, int dim, double p);
double euclideanDistance(double *, double *, int);
double euclideanNorm(double *, int);
void scalarTimesVector(double *, double, int);
double innerProduct(double *, double *, int);
void vectorDifference(double *, double *, double *, int);
void vectorTimesMatrix(double *A, double *x, double *b,  int dim);

#endif