
#ifndef _INDICATOR_
#define _INDICATOR_

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <float.h>
#include <math.h>


#include "indicator.h"
#include "sort.h"
#include "io.h"
#include "matrix.h"
#include "vector.h"


#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))


/**********************************   INVERTED GENERATIONAL DISTANCE PLUS (IGD+) ************************************/
double EMO_vdist(double *x, double *y, int n) {
  double v = 0;
  int i;

  for(i = 0; i < n; i++)
    v += (x[i] - y[i]) * (x[i] - y[i]);
  
  return sqrt(v);
}

double EMO_Indicator_igd_plus_moea(double *f, int *filter, int n, double *pf, int m, int dim, EMO_IC *igdplus_mem){
  double s;
  int i;
  s = 0.0;
  for(i = 0; i < m; i++)
    s += mindist_plus_moea(pf + i*dim, f, filter, n, dim, &igdplus_mem[i]);
  return s / (double) m;
}

/* v: reference vector
 * f: population
 * filter: active population
 * n: population size
 * dim: number of objectives
 */
double mindist_plus_moea(double *v, double *f, int *filter, int n, int dim, EMO_IC *igdplus_mem) {
    double min, d, s, aux_min;
    int i, j;

    min = DBL_MAX;
    d = 0;
    double *dplusdistances;
    dplusdistances = (double *)malloc(n * sizeof(double));
    // Find the minimum distance from vector v to set of vectors f
    for(i = 0; i < n; i++) {
        if(filter[i]) {
            s = 0;
            for(j = 0; j < dim; j++) {
                d = MAX(f[i*dim + j] - v[j], 0);
                s += d * d;
            }
            d = sqrt(s);
            dplusdistances[i] = d;
            if(d < min){
                igdplus_mem->index_best = i;
                igdplus_mem->v_best = d;
                min = d;
            }
        }
    }

    aux_min = DBL_MAX;
    for(i = 0; i < n; i++){
        if(filter[i] && i != igdplus_mem->index_best && dplusdistances[i] < aux_min){
                aux_min = dplusdistances[i]; 
                igdplus_mem->v_second = aux_min;
                igdplus_mem->index_second = i;
        }
    }
    free(dplusdistances);
    return min; 
}

double EMO_Indicator_igd_plus_contribution(double *cigdplus, double *A, int *enable, int n, double *Z, int m, int dim, EMO_IC *igdplus_mem) {
    double totaligdplus;
    int i, j;
    // Calculates the total GD induced by all enabled solutions
    totaligdplus = EMO_Indicator_igd_plus_moea(A, enable, n, Z, m, dim, igdplus_mem);
 
    for(i = 0; i < n; i++){
        if(enable[i]){
            double c = 0.0;
            for(j = 0; j < m; j++)
                c += (igdplus_mem[j].index_best == i) ? igdplus_mem[j].v_second : igdplus_mem[j].v_best;
            c /= (double) m;
            cigdplus[i] = fabs(totaligdplus - c);
        }else{
            cigdplus[i] = DBL_MAX;
        }
    }
    return totaligdplus;
}

double EMO_Indicator_igd_plus_contribution_pcui(double *cigdplus, double *A, int *enable, int n, double *Z, int m, int dim, EMO_IC *igdplus_mem) {
    double totaligdplus;
    int i, j;
    // Calculates the total GD induced by all enabled solutions
    totaligdplus = EMO_Indicator_igd_plus_moea(A, enable, n, Z, m, dim, igdplus_mem);
 
    for(i = 0; i < n; i++){
        if(enable[i]){
            double c = 0.0;
            for(j = 0; j < m; j++)
                c += (igdplus_mem[j].index_best == i) ? igdplus_mem[j].v_second : igdplus_mem[j].v_best;
            c /= (double) m;
            cigdplus[i] = -1.0 * c; // Calcula -IGD+(A \ {a}, Z)
        }else{
            cigdplus[i] = DBL_MAX;
        }
    }
    return -1.0 * totaligdplus;
}

void mindist_igd(int *filter, int n, int m, EMO_IC *igd_c, double *D){
  int i, j;

  //#pragma omp parallel for private(j)
  for(i = 0; i < m; i++){
    double min = DBL_MAX;
    // Find the minimum distance
    for(j = 0; j < n; j++){
      if(filter[j]){
        if(D[i*n + j] < min){
          min = D[i*n + j];
          igd_c[i].v_best = min;
          igd_c[i].index_best = j;          
        }
      }
    }
    min = DBL_MAX;
    for(j = 0; j < n; j++){
        if(filter[j] && j != igd_c[i].index_best && D[i*n + j] < min){
            min = D[i*n + j];
            igd_c[i].v_second = min;
            igd_c[i].index_second = j; 
        }
    }
  }
}


/*********************************  AVERAGED HAUSDORFF DISTANCE (DELTAp) ***************************/
void mindist_gd(int *filter, int n, int m, double *gd_c, double *D){
    int i, j;
    //#pragma omp parallel for private(j)
    for(i = 0; i < n; i++){
        if(filter[i]){
            double min = DBL_MAX;
            for(j = 0; j < m; j++){
                if(D[j*n + i] < min){
                    min = D[j*n + i];
                    gd_c[i] = min;
                }
            }
        }else{
            gd_c[i] = DBL_MAX;
        }
    }
}

double EMO_Indicator_gdp_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, double *gd_c, double *D) {
  double s;
  int i, size = 0;


  mindist_gd(filter, n, m, gd_c, D);
  s = 0.0;
  for(i = 0; i < n; i++)
    if(filter[i]){
      s += pow(gd_c[i], p);
      size++;
    }

  return pow(s / (double) size, 1.0 / p);
}

double EMO_Indicator_igdp_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *D) {
  double s;
  int i;

  mindist_igd(filter, n, m, igd_c, D);
  s = 0.0;
  for(i = 0; i < m; i++)
    s += pow(igd_c[i].v_best, p);

  return pow(s / (double) m, 1.0 / p);
}

double EMO_Indicator_deltap_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *gd_c, double *D) {
  int i, j;
  double igd, gd;

  // Calculate matrix of Euclidean distances that both GD and IGD require
  //#pragma omp parallel for private(j)
  for(i = 0; i < m; i++)
    for(j = 0; j < n; j++)  
        D[i*n + j] = (filter[j]) ? EMO_vdist(pf + i*dim, f + j*dim, dim) : DBL_MAX;

  igd = EMO_Indicator_igdp_moea(f, filter, n, pf, m, dim, p, igd_c, D);
  gd = EMO_Indicator_gdp_moea(f, filter, n, pf, m, dim, p, gd_c, D);

  if(gd > igd) return gd;

  return igd;
}

double EMO_Indicator_deltap_contribution(double *cdeltap, double *A, int *enable, int n, double *Z, int m, int dim, double p, EMO_IC *igd_c, double *gd_c, double *D) {
  double totaldeltap;
  int i, j, size = 0;

  for(i = 0; i < n; i++)
    if(enable[i])
      size++;

  // Calculates the total GD induced by all enabled solutions
  totaldeltap = EMO_Indicator_deltap_moea(A, enable, n, Z, m, dim, p, igd_c, gd_c, D);
  //#pragma omp parallel for private(j)
  for(i = 0; i < n; i++){
    if(enable[i]){     
      double cIGD = 0, cGD = 0;

      for(j = 0; j < m; j++)
        if(igd_c[j].index_best == i)
          cIGD += pow(igd_c[j].v_second, p);
        else
          cIGD += pow(igd_c[j].v_best, p);
      cIGD = pow( cIGD / (double) m, 1.0 / p);

      for(j = 0; j < n; j++)
        if(enable[j] && j != i)
          cGD += pow(gd_c[j], p);
      cGD = pow(cGD / (double) (size - 1), 1.0 / p);
      
      cdeltap[i] = (cGD > cIGD)? fabs(totaldeltap - cGD) : fabs(totaldeltap - cIGD);    
    }else{
      cdeltap[i] = DBL_MAX;
    }
  }

  return totaldeltap;
}

/******************************** GENERATIONAL DISTANCE *********************************/
double EMO_Indicator_gd_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, double *gd_c, double *D) {
  double s;
  int i, size = 0;


  mindist_gd(filter, n, m, gd_c, D);
  s = 0.0;
  for(i = 0; i < n; i++)
    if(filter[i]){
      s += pow(gd_c[i], p);
      size++;
    }

  return pow(s, 1.0 / p) / (double) size;
}

double EMO_Indicator_gd_contribution(double *cgd, double *f, int *filter, int n, double *pf, int m, int dim, double p, double *gd_c, double *D){
  double totalgd;
  int i, j, size = 0;

  for(i = 0; i < n; i++)
    if(filter[i])
      size++;


  for(i = 0; i < m; i++)
    for(j = 0; j < n; j++)  
        D[i*n + j] = (filter[j]) ? EMO_vdist(pf + i*dim, f + j*dim, dim) : DBL_MAX;

  totalgd = EMO_Indicator_gd_moea(f, filter, n, pf, m, dim, p, gd_c, D);


   for(i = 0; i < n; i++){
    if(filter[i]){     
      double cGD = 0;

      for(j = 0; j < n; j++)
        if(filter[j] && j != i)
          cGD += pow(gd_c[j], p);
      cGD = pow(cGD / (double) (size - 1), 1.0 / p);
      
      cgd[i] = fabs(totalgd - cGD);  
    }else{
      cgd[i] = DBL_MAX;
    }
  }
  return totalgd;
}

/******************************** INVERTED GENERATIONAL DISTANCE ***************************************/
double EMO_Indicator_igd_moea(double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *D) {
  double s;
  int i;

  mindist_igd(filter, n, m, igd_c, D);
  s = 0.0;
  for(i = 0; i < m; i++)
    s += pow(igd_c[i].v_best, p);

  return pow(s, 1.0 / p) / (double) m;
}

double EMO_Indicator_igd_contribution(double *cigd, double *f, int *filter, int n, double *pf, int m, int dim, double p, EMO_IC *igd_c, double *D){
  double totaligd;
  int i, j;


  for(i = 0; i < m; i++)
    for(j = 0; j < n; j++)  
        D[i*n + j] = (filter[j]) ? EMO_vdist(pf + i*dim, f + j*dim, dim) : DBL_MAX;

  totaligd = EMO_Indicator_igd_moea(f, filter, n, pf, m, dim, p, igd_c, D);


   for(i = 0; i < n; i++){
    if(filter[i]){     
      double cIGD = 0;

      for(j = 0; j < m; j++)
        if(igd_c[j].index_best == i)
          cIGD += pow(igd_c[j].v_second, p);
        else
          cIGD += pow(igd_c[j].v_best, p);
      cIGD = pow( cIGD / (double) m, 1.0 / p);

      cigd[i] = fabs(totaligd - cIGD);
    }else{
      cigd[i] = DBL_MAX;
    }
  }
  return totaligd;
}

/******************************** R2 INDICATOR ****************************************/

double EMO_Indicator_r2_moea(double *data, int *filter, int size, double *W, int wsize, UTILITY *utl, EMO_IC *r2_c){
    double d, s = 0;
    int i, j;
    double *utilities;
    utilities = (double *) malloc(size * sizeof(double));
    for(i = 0; i < wsize; i++) {
        // Find the optimal value of utility function
        double vmin = DBL_MAX;
        for(j = 0; j < size; j++) {
            if(filter[j]) {
                d = utl->uf(utl,  data + j * utl->nobj, &W[i * utl->nobj]);
                utilities[j] = d;
                if(d < vmin){
                    vmin = d; 
                    r2_c[i].v_best = vmin;
                    r2_c[i].index_best = j;
                }
            }
        }
        s += vmin;
        vmin = DBL_MAX;
        for(j = 0; j < size; j++){
            if(filter[j] && j != r2_c[i].index_best && utilities[j] < vmin){
                vmin = utilities[j]; 
                r2_c[i].v_second = vmin;
                r2_c[i].index_second = j;
            }
        }
    }
    free(utilities);  
    return s/wsize;
}

double EMO_Indicator_r2_contribution(double *cr2, double *data, int *enable, int n, double *W, int wsize, UTILITY *utl, EMO_IC *r2_c){
    double totalr2;
    int i, j;

    // Calculates the total R2 induced by all enabled solutions
    totalr2 = EMO_Indicator_r2_moea(data, enable, n, W, wsize, utl, r2_c); 
    //#pragma omp parallel for private(j)
    for(i = 0; i < n; i++){
        if(enable[i]){
            double c = 0.0;
            for(j = 0; j < wsize; j++)
                c += (r2_c[j].index_best == i) ? r2_c[j].v_second : r2_c[j].v_best;
            c /= (double) wsize;
            cr2[i] = fabs(totalr2 - c);
        }
    }
    return totalr2;
}

double EMO_Indicator_r2_contribution_pcui(double *cr2, double *data, int *enable, int n, double *W, int wsize, UTILITY *utl, EMO_IC *r2_c){
    double totalr2;
    int i, j;

    // Calculates the total R2 induced by all enabled solutions
    totalr2 = EMO_Indicator_r2_moea(data, enable, n, W, wsize, utl, r2_c); 
    //#pragma omp parallel for private(j)
    for(i = 0; i < n; i++){
        if(enable[i]){
            double c = 0.0;
            for(j = 0; j < wsize; j++)
                c += (r2_c[j].index_best == i) ? r2_c[j].v_second : r2_c[j].v_best;
            c /= (double) wsize;
            cr2[i] = -1.0 * c; // Calcula -R2(A \ {a}, W)
        }
    }
    return -1.0 * totalr2;
}

/********************************* ADDITIVE EPSILON INDICATOR ************************/

double EMO_Indicator_epsilon_additive(double *a, int na, int *enableA, double *b, int nb, int *enableB, int dim) {
  double diff, eps, eps_a, eps_obj;
  int i, j, k;

  for(i = 0; i < nb; i++) {
    if(enableB[i]){
      for(j = 0; j < na; j++) {
        if(enableA[j]){
          eps_obj = a[j*dim] - b[i*dim];

          for(k = 1; k < dim; k++) {
            diff = a[j*dim + k] - b[i*dim + k];

            if(diff > eps_obj)  // max k
              eps_obj = diff;
          }
          if(j == 0 || eps_obj < eps_a)  // min a
            eps_a = eps_obj;
        }
      }

      if(i == 0 || eps_a > eps)  // max b
        eps = eps_a;
    }
  }
  return eps;
}

double EMO_Indicator_epsilon_additive_moea(double *a, int *filter, int na, double *b, int nb, int dim, EMO_IC *epsadd_c) {
    double diff, eps, eps_a, eps_obj;
    int i, j, k;

    double *deviations;
    deviations = (double *) malloc(na * sizeof(double));

    // For each element in b (the reference set)
    for(i = 0; i < nb; i++) {
        // For each element in a (the approximation set). c1 is a counter of the active solutions.
        for(j = 0; j < na; j++) {
            // If the element in a in enabled
            if(filter[j]){
                // First deviation
                eps_obj = a[j*dim] - b[i*dim];
                // Compute the remaining differences
                for(k = 1; k < dim; k++) {
                    diff = a[j*dim + k] - b[i*dim + k];
                    // Getting the maximum difference
                    if(diff > eps_obj)  // max k
                        eps_obj = diff;
                }
                deviations[j] = eps_obj;
            }
        }
        eps_a = DBL_MAX;
        for(j = 0; j < na; j++){
            if(filter[j] && deviations[j] < eps_a){
                eps_a = deviations[j];
                epsadd_c[i].v_best = eps_a;
                epsadd_c[i].index_best = j;
            }
        }
        // Getting the maximum among all minimum differences (last steo to set epsilon)
        if(i == 0 || eps_a > eps)  // max b
            eps = eps_a;

        eps_a = DBL_MAX;
        for(j = 0; j < na; j++){
            if(filter[j] && j != epsadd_c[i].index_best && deviations[j] < eps_a){
                eps_a = deviations[j];
                epsadd_c[i].v_second = eps_a;
                epsadd_c[i].index_second = j;  
            }
        }
    }
    free(deviations);
    return eps;
}

double EMO_Indicator_epsilon_additive_contribution(double *cepsadd, double *A, int *enable, int n, double *Z, int m, int dim, EMO_IC *epsadd_c) {
    double totalepsadd;
    int i, j;

    // Calculates the total epsilon additive induced by all enabled solutions
    totalepsadd = EMO_Indicator_epsilon_additive_moea(A, enable, n, Z, m, dim, epsadd_c);
    //#pragma omp parallel for private(j)
    for(i = 0; i < n; i++){
        if(enable[i]){
            double max = -DBL_MAX, aux;
            for(j = 0; j < m; j++){
                aux = (epsadd_c[j].index_best == i) ? epsadd_c[j].v_second : epsadd_c[j].v_best;
                if(aux > max)
                    max = aux;
            }
            cepsadd[i] = fabs(totalepsadd - max);
        }
    }
    return totalepsadd;
}

double EMO_Indicator_epsilon_additive_contribution_pcui(double *cepsadd, double *A, int *enable, int n, double *Z, int m, int dim, EMO_IC *epsadd_c) {
    double totalepsadd;
    int i, j;

    // Calculates the total epsilon additive induced by all enabled solutions
    totalepsadd = EMO_Indicator_epsilon_additive_moea(A, enable, n, Z, m, dim, epsadd_c);
    //#pragma omp parallel for private(j)
    for(i = 0; i < n; i++){
        if(enable[i]){
            double max = -DBL_MAX, aux;
            for(j = 0; j < m; j++){
                aux = (epsadd_c[j].index_best == i) ? epsadd_c[j].v_second : epsadd_c[j].v_best;
                if(aux > max)
                    max = aux;
            }
            cepsadd[i] = -1.0 * max; // Calcula -EPS+(A \ {a}, Z)
        }
    }
    return -1.0 * totalepsadd;
}



/************************************** RIESZ S-ENERGY ***********************************/
double EMO_Indicator_s_energy_moea(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
    double s_energy = 0.0;
    int i, j;
    //#pragma omp parallel for private(i)
    for(j = 0; j < n; j++){
        if(filter[j]){
            double s_aux = 0.0;
            for(i = 0; i < n; i++){
                if(i != j && filter[i]){
                    double aux, dist;
                    dist = EMO_vdist(f + j*dim, f +i*dim, dim);
                    if(dist == 0)
                        dist = 1e-4;
                    aux = (s == 0.0)? log(1.0/dist) : pow(dist, -s);  

                    s_energy_c[j*(n + 1) + i] = aux;     
                    s_aux += aux;
                }
            }
            s_energy_c[j*(n + 1) + n] = s_aux;
            s_energy += s_aux;
        }
    }
    return s_energy;
}

double EMO_Indicator_s_energy_contribution(double *csenergy, double *f, int *filter, int n, double s, int dim, double *s_energy_c){
  double s_energy;
  int j, k;

  s_energy = EMO_Indicator_s_energy_moea(f, filter, n, s, dim, s_energy_c)/pow(n, 2);
  //#pragma omp parallel for private(j)
  for(k = 0; k < n; k++){
    if(filter[k]){
      double aux = 0.0;
      for(j = 0; j < n; j++){
        if(filter[j]){
          if(j == k) continue;
          aux += s_energy_c[j*(n + 1) + n] - s_energy_c[j*(n + 1) + k];
        }
      }
      aux /= pow(n - 1, 2);
      csenergy[k] = (s_energy - aux)/2.0;
    }
  }
  return s_energy;
}


/************************************* HAUSDORFF DISTANCE *****************************/

double EMO_Indicator_Hausdorff_Distance(double *X, int N, double *Y, int M, int dim){
  int i, j;
  double *d, maxXY, maxYX, HD, dist;
  d = (double *) malloc((N + 1) * (M + 1) * sizeof(double));
  // Initialize max values for each x in X
  for(i = 0; i < N; i++)
    d[i * (M + 1) + M] = DBL_MAX;
  // Initialize max values for each y in Y
  for(j = 0; j < M; j++)
    d[N * (M + 1) + j] = DBL_MAX;

  for(i = 0; i < N; i++){
    for(j = 0; j < M; j++){
      dist = EMO_vdist(&X[i * dim], &Y[j * dim], dim);
      d[i * (M + 1) + j] = dist;

      if(dist < d[i * (M + 1) + M])
        d[i * (M + 1) + M] = dist;

      if(dist < d[N * (M + 1) + j])
        d[N * (M + 1) + j] = dist;
    }
  }

  maxXY = maxYX = -DBL_MAX;

  for(i = 0; i < N; i++){
    if(d[i * (M + 1) + M] > maxXY){
      maxXY = d[i * (M + 1) + M];
    }
  }

  for(j = 0; j < M; j++){
    if(d[N * (M + 1) + j] > maxYX){
      maxYX = d[N * (M + 1) + j];
    }
  }

    HD = MAX(maxXY, maxYX);


  free(d);
  return HD;
}


/************************************************************** STRUCTURES FOR INDICATOR-BASED DENSITY ESTIMATORS ***************************************/

void allocate_ic(IC *ic, int asize, int zsize){
    if((ic->C = (double *) malloc(asize * sizeof(double))) == NULL){
        printf("Error, not enough memory for generic array of contributions\n");
        exit(-1);
    }

    if((ic->memoization = (EMO_IC *) malloc(sizeof(EMO_IC) * zsize)) == NULL) {
        printf("Error, not enough memory for generic memoization structure");
        exit(-1);
    }
}

void free_ic(IC *ic){
    free(ic->C);
    free(ic->memoization);
}

void allocate_r2(R2_contribution *r2c, int n, char *weightsFile, char *utl_name){
  int nobj;
  nobj = r2c->wsize = 0;
  r2c->W = readFile(NULL, &r2c->wsize, &nobj, weightsFile, 0);
  UTILITY_alloc(&r2c->utl, utl_name, nobj);

  if((r2c->cr2 = (double *) malloc(sizeof(double) * n)) == NULL) {
      printf("Error, not enough memory in R2-EMOA\n");
      exit(1);
    }

    if((r2c->memoization = (EMO_IC *) malloc(sizeof(EMO_IC) * r2c->wsize)) == NULL){
      printf("Error, not enough memory in R2-EMOA\n");
      exit(1);
    }
}

void free_r2(R2_contribution *r2c){
  free(r2c->W);
  free(r2c->memoization);
  free(r2c->cr2);
  UTILITY_free(&r2c->utl);
}

void allocate_hv(HV_contribution *hvc, int n, int nobj){
    EMO_HV_alloc(&hvc->hv, n, nobj);

    if((hvc->chv = (double *) malloc(sizeof(double) * n)) == NULL) {
        printf("Error, not enough memory for HV contribution array\n");
        exit(1);
    }

    if((hvc->ref = (double *) malloc(sizeof(double) * nobj)) == NULL){
        printf("Error, not enough memory for HV reference point array\n");
        exit(1);
    }
}

void free_hv(HV_contribution *hvc){
    EMO_HV_free(&hvc->hv);
    free(hvc->ref);
    free(hvc->chv);
}

void allocate_deltap(DELTAp_contribution *dpc, int asize, int zsize, double p){
    dpc->p = p;

    if((dpc->igd_c = (EMO_IC *) malloc(sizeof(EMO_IC) * zsize)) == NULL) {
        printf("Error, not enough memory for IGD memoization structure\n");
        exit(1);
    }

    if((dpc->gd_c = (double *) malloc(sizeof(double) * asize)) == NULL) {
        printf("Error, not enough memory in GD memoization structure\n");
        exit(1);
    }

    if((dpc->D = (double *) malloc(sizeof(double) * asize * zsize)) == NULL) {
        printf("Error, not enough memory for cost matrix delta p\n");
        exit(1);
    }

    if((dpc->cdeltap = (double *) malloc(sizeof(double) * asize)) == NULL) {
        printf("Error, not enough memory for delta p contribution array\n");
        exit(1);
    }
}

void free_deltap(DELTAp_contribution *dpc){
    free(dpc->igd_c);
    free(dpc->gd_c);
    free(dpc->D);
    free(dpc->cdeltap);
}


int findMax(double *data, int size, int *filter){
  int i, index = 0;
  double max = -DBL_MAX;
  for(i = 0; i < size; i++){
    if(filter[i] && data[i] > max){
      max = data[i];
      index = i;
    }
  }
  return index;
}

int findMin(double *data, int size, int *filter){
  int i, index = 0;
  double min = DBL_MAX;
  for(i = 0; i < size; i++){
    if(filter[i] && data[i] < min){
      min = data[i];
      index = i;
    }
  }
  return index;
}




/************************************** INDICATORS FOR ASSESSMENT **************************/

/* v: reference vector
 * f: population
 * filter: active population
 * n: population size
 * dim: number of objectives
 */
double mindist_plus(double *v, double *f, int *filter, int n, int dim) {
  double min, d, s;
  int i, j;

  min = DBL_MAX;
  d = 0;

  if(filter == NULL) {
    for(i = 0; i < n; i++) {
      s = 0;

      for(j = 0; j < dim; j++) {
        d = MAX(f[i*dim + j] - v[j], 0);  /* minimization problems: a_i - zref_i */
        s += d * d;
      }

      d = sqrt(s);

      if(d < min) min = d;
    }
  }
  else {
    for(i = 0; i < n; i++) {
      if(filter[i]) {
        s = 0;

        for(j = 0; j < dim; j++) {
          d = MAX(f[i*dim + j] - v[j], 0);
          s += d * d;
        }

        d = sqrt(s);

        if(d < min) min = d;
      }
    }
  }

  return min; 
}

/* Professor Ishibuchi */
double EMO_Indicator_igd_plus(double *f, int *filter, int n, double *pf, int m, int dim) {
  double s;
  int i;

  s = 0.0;

  for(i = 0; i < m; i++) {
    s += mindist_plus(pf+i*dim, f, filter, n, dim);
  }

  return s / (double) m;
}


double EMO_Indicator_r2(double *data, int *filter, int size, double *W, int wsize, UTILITY *utl) {
  double d, vmin = 0, s = 0;
  int i, j;

  if(filter == NULL) {
    for(i = 0; i < wsize; i++) {
      vmin = DBL_MAX;

      for(j = 0; j < size; j++) {
        d = utl->uf(utl,  &data[j * utl->nobj], &W[i * utl->nobj]);
        if(d < vmin) vmin = d; 
      }
      s += vmin;
    }
  }
  else {
    for(i = 0; i < wsize; i++) {
      vmin = DBL_MAX;

      for(j = 0; j < size; j++) {
        if(filter[j]) {
          d = utl->uf(utl,  &data[j * utl->nobj], &W[i * utl->nobj]);

          if(d < vmin) vmin = d; 
        }
      }
      s += vmin;
    }
  }
  return s/wsize;
}

double mindist(double *v, int *filter, double *f, int n, int dim) {
  double min, d;
  int i;

  min = DBL_MAX;
  d = 0;

  if(filter == NULL) {
    for(i = 0; i < n; i++) {
      d = EMO_vdist(v, f+i*dim, dim);

      if(d < min) min = d;
    }
  }
  else {
    for(i = 0; i < n; i++) {
      if(filter[i]) {
        d = EMO_vdist(v, f+i*dim, dim);

        if(d < min) min = d;
      }
    }
  }

  return min; 
}
/* Average distance from the aproximation set to the
   discretization of the Pareto front */
double EMO_Indicator_gd(double *f, int *filter, int n, double *pf, int m, int dim, double p) {
  double s;
  int i;

  s = 0.0;

  if(filter == NULL) {
    for(i = 0; i < n; i++)
      s += pow(mindist(f+i*dim, NULL, pf, m, dim), p);
  }
  else {
    for(i = 0; i < n; i++)
      if(filter[i])
        s += pow(mindist(f+i*dim, NULL, pf, m, dim), p);
  }

  return pow(s / (double) n, 1.0 / p);
}

/* Average distance from the discretization of the
   Pareto front to the aproximation set */
double EMO_Indicator_igd(double *f, int *filter, int n, double *pf, int m, int dim, double p) {
  double s;
  int i;

  s = 0.0;

  for(i = 0; i < m; i++)
    s += pow(mindist(pf+i*dim, filter, f, n, dim), p);

  return pow(s / (double) m, 1.0 / p);
}

double EMO_Indicator_deltap(double *f, int *filter, int n, double *pf, int m, int dim, double p) {
  double igd, gd;

  igd = EMO_Indicator_igd(f, filter, n, pf, m, dim, p);
  gd = EMO_Indicator_gd(f, filter, n, pf, m, dim, p);

  if(gd > igd) return gd;

  return igd;
}

// Solow and Polasky Diversity
// to be maximized
// SPD returns a value between 1 and n (0 if there is an error), 
// which can be interpreted as the number of species
double EMO_Indicator_solow_polasky(double *f, int *filter, int n, int dim) {
  double *m, *c;
  double v, theta = 10.0;
  int i, j, k, l, size;
  int *filter2;

  filter2 = (int *) malloc(sizeof(int) * n);

  for(i = 0; i < n; i++)
    filter2[i] = 1;

  size = n;

  for(i = 0; i < n; i++) {
    for(j = i+1; j < n; j++) {
      v = EMO_vdist(f + i * dim, f + j * dim, dim);

      if(v == 0 && filter2[j]) {
        filter2[j] = 0;
        size--;
      }
    } 
  }


  m = (double *) malloc(sizeof(double) * size * size);
  c = (double *) malloc(sizeof(double) * size * size);

  for(i = 0, k = 0; i < n; i++) {

    if(!filter2[i]) {
      continue;
    }

    for(j = 0, l = 0; j < n; j++) {

      if(!filter2[j]) {
        continue;
      }

      v = (i == j)? 0.0 : EMO_vdist(f + i * dim, f + j * dim, dim);
      m[k*size + l] = exp(-theta * v);
      l++;
    }
    k++;
  }

  if(EMO_minverse(c, m, size, 1, 0, 0) == 1) {
    printf("Error to calculate the inverse\n");
    free(filter2);
    free(m);
    free(c);
    return 0.0;
  }

  v = 0;

  for(i = 0; i < size; i++)
    for(j = 0; j < size; j++)
      v += c[i*size + j];

  free(filter2);
  free(m);
  free(c);

  return v;
}


// Discretizing Manifolds via Minimum Energy Points
// D.P. Hardin and E.B. Saff, 2004
//
// Generalized Decomposition
// Ioannis Giagkiozis, Robin C. Purshouse, and Peter J. Fleming, 2013
//
// Riesz s-energy

double EMO_Indicator_senergy(double *f, int *filter, int n, int dim) {
  double v, s1, s2;
  int i, j;

  s2 = 0;

 

  for(i = 0; i < n; i++) {
    s1 = 0;

    if(filter != NULL && filter[i] == 0) continue;

    for(j = i+1; j < n; j++) {

      if(filter != NULL && filter[j] == 0) continue;

      v = EMO_vdist(f + i*dim, f + j*dim, dim);

      if(v == 0) {
        v = 1e-4;
      }

      v = pow(v, -(dim - 1.0));

      
      s1 += v;
      s2 += 2.0 * v;
    }
  }

  return s2;
}





double EMO_Indicator_PD(double *A,  int N, int dim){
  double *C, *D, *d, aux, score = 0.0;
  int *J, *P, *newP;

  int i, j, t, k, auxOR;
  C = (double *) calloc(N * N, sizeof(double));
  D = (double *) malloc(N * N * sizeof(double));
  d = (double *) malloc(N * sizeof(double));

  P = (int *) malloc(N * sizeof(int));
  newP = (int *) malloc(N * sizeof(int));
  J = (int *) malloc(N * sizeof(int));

  for(i = 0; i < N; i++)
    C[i * N + i]= 1;
  // Compute dissimilarity matrix
  for(i = 0; i < N; i++)
    for(j = 0; j < N; j++)
        D[i * N + j] = (i == j)? DBL_MAX : minkowski_distance(&A[i * dim], &A[j * dim], dim, 0.1);
  
  for(k = 0; k < N - 1; k++){
    while(1){

      for(t = 0; t < N; t++){
        d[t] = DBL_MAX;
        for(j = 0; j < N; j++){
          if(D[t * N + j] < d[t]){
            d[t] = D[t * N + j];
            J[t] = j;
          }
        }
      }

      aux = -DBL_MAX;
      for(j = 0; j < N; j++){
        if(d[j] > aux){
          aux = d[j];
          i = j;
        }
      }

      if(D[J[i] * N + i] != -DBL_MAX)
        D[J[i] * N + i] = DBL_MAX;
      if(D[i * N + J[i]] != -DBL_MAX)
        D[i * N + J[i]] = DBL_MAX;

      for(t = 0; t < N; t++){
        P[t] = (C[i * N + t] > 0) ? 1 : 0;
      }

      while(!P[J[i]]){
        for(t = 0; t < N; t++){
          auxOR = 0;
          for(j = 0; j < N; j++){


              if(C[j * N + t] == 1 && P[j] == 1){
                auxOR = 1;
                break;
              }
            
          }
          newP[t] = auxOR;
        }


        int areEqual = 1;
        for(t = 0; t < N; t++){
          if(P[t] != newP[t]){
            areEqual = 0;
            break;
          }
        }

        if(areEqual){
          break;
        }else{
          for(t = 0; t < N; t++){
            P[t] = newP[t];
          }
        }
      }


      if(!P[J[i]]){
        break;
      }
    }
    C[i * N + J[i]] = 1;
    C[J[i] * N + i] = 1;
    for(j = 0; j < N; j++){
      D[i * N + j] = -DBL_MAX;
    }
    score += d[i];
  }
  free(C);
  free(D);
  free(P);
  free(newP);
  free(d);
  free(J);
  return score;
}
#endif

