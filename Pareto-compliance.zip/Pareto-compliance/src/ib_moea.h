#ifndef _IB_MOEA_H_
#define _IB_MOEA_H_

#include "population.h"
#include "mop.h"
#include "indicator.h"
#include "M3.h"
#include "Rand.h"
#include "PCUI_SSS.h"
#include "archive.h"
#include "Monitor.h"


#define HV 1
#define R2 2
#define IGDplus 3
#define EPSplus 4
#define DELTAp 5
#define IGD 6
#define GD 7
#define R2plusplus 8
#define IGDplusplus 9
#define EPSplusplus 10

typedef struct{
	/* POPULATION INFORMATION */
	int mu;							// Number of parents.
	int lambda;						// Number of offsprings.
	int N;							// N = mu + lambda.
	/* GENETIC PARAMETERS */
	int Nc;					
	int Nm;
	double pc;
	double pm;
	/* STOPPING CRITERION */
	int maxFeval;						// Each IB-MOEA employs a maximum number of generations as stopping criterion.
	/* REFERENCE INFORMATION */
	double *zmin;					// Ideal vector.
	double *zmax;					// Nadir vector.
	double *Z;						// Reference set.
	int zsize;
	/* IB-DENSITY ESTIMATION */
	IC igdplus_DE;
	IC epsplus_DE;
	DELTAp_contribution dp_DE;
	HV_contribution hv_DE;
	R2_contribution r2_DE;

	EMOPCUI pcui;
	int QIcode;
	/* AUXILIAR STRUCTURES */
	int *filter;
	/* STRUCTURES */
	M3NDsorting m3nd;				// Data structure for nondominated sorting.
	/* RANDOM NUMBER GENERATOR */
	EMO_Rand rnd;


	/* Archive = Reference Set */
	Archive arch;
}IB_MOEA;


void IB_MOEA_allocate(IB_MOEA *ibmoea, int nvar, int nobj, char *QI, char *param_name);
void IB_MOEA_free(IB_MOEA *);
void IB_MOEA_run(IB_MOEA *, Population *, MOP *, int exec, MONITOR *monitor);
void IB_MOEA_select_worst_solutions(IB_MOEA *, Population *, MOP *, int);

#endif