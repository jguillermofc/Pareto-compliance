#include "archive.h"
#include "M3.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>



void Archive_allocate(Archive *arch, int nvar, int nobj, int mu, int lambda){
	arch->Amax = mu; // Set archive maximum size
	arch->csize = 0;
	arch->vsize = mu + lambda;
	if((arch->filter = (int *) malloc(arch->vsize * sizeof(int))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}
	
	EMO_PP_allocate(&arch->ppc, arch->vsize);
	Population_allocate(&arch->pop, mu + lambda, nvar, nobj);
}

void Archive_free(Archive *arch){
	free(arch->filter);
	EMO_PP_free(&arch->ppc);
	Population_free(&arch->pop);
}

// Put all individuals together in a block.
void Archive_exchange(Archive *arch, int nvar, int nobj){
	int i, j;
	for(i = 0; i < arch->csize; i++){
		if(!arch->filter[i]){
			// The ith cel in filter is empty, look for the first nondominated solution
			for(j = i + 1; j < arch->csize; j++){
				if(arch->filter[j]){
					// The element is nondominated. Copy it into the ith position.
					memcpy(&arch->pop.F[i * nobj], &arch->pop.F[j * nobj], nobj * sizeof(double));
					memcpy(&arch->pop.x[i * nvar], &arch->pop.x[j * nvar], nvar * sizeof(double));
					arch->filter[j] = 0;
					arch->filter[i] = 1;
					break;
				}
			}
		}
	}
}

void Archive_initialize(Archive *arch, Population *pop, int mu, int nobj, int nvar){
	memcpy(arch->pop.F, pop->F, mu * nobj * sizeof(double));
	memcpy(arch->pop.x, pop->x, mu * nvar * sizeof(double));

	memset(arch->filter, 0, arch->vsize * sizeof(int));
	memset(arch->filter, 1, mu * sizeof(int));
	arch->csize = mu;
}

void Archive_insert(Archive *arch, double *x, double *F, int nvar, int nobj){
	int j, aux_size = arch->csize, result, sentinel, added = 0;
	
	sentinel = 1;
	for(j = 0; j < arch->csize; j++){
		if(arch->filter[j]){
			result = ParetoDominance(F, &arch->pop.F[j * nobj], nobj);
			if(result == 1){
				arch->filter[j] = 0; // Turning off dominated solution.
				aux_size--;
			}else if(result == -1 || result == 2){
				sentinel = 0; // Set sentinel to zero so that the solution is not inserted.
				break;
			}
		}
	}
	// Insert solution in the nearest available cell to the last occupied cell.
	if(sentinel){
		memcpy(&arch->pop.x[(arch->csize + added) * nvar], x, nvar * sizeof(double));
		memcpy(&arch->pop.F[(arch->csize + added) * nobj], F, nobj * sizeof(double));
		arch->filter[arch->csize + added] = 1;
		added++;
		aux_size++;
	}	

	arch->csize += added;
	Archive_exchange(arch, nvar, nobj);
	memset(arch->filter, 0, arch->vsize * sizeof(int));
	memset(arch->filter, 1, aux_size * sizeof(int));
	arch->csize = aux_size;
}

void Archive_PairPotential_prunning(Archive *arch, double *zmin, double *zmax, int nvar, int nobj){
	if(arch->csize > arch->Amax){
		// Normalize
		Population_get_ideal(&arch->pop, arch->csize, zmin, nobj);
		Population_get_nadir(&arch->pop, arch->csize, zmax, nobj);
		Population_normalize(&arch->pop, arch->csize, zmin, zmax, nobj);
		// Apply Pair Potential-based steady-state selection
		EMO_PP_greedySelection(arch->pop.Fnorm, arch->filter, arch->csize, arch->Amax, nobj, &arch->ppc, arch->ppc.pp);
		Archive_exchange(arch, nvar, nobj);
		memset(arch->filter, 0, arch->vsize * sizeof(int));
		memset(arch->filter, 1, arch->Amax * sizeof(int));
		arch->csize = arch->Amax;
	}
}