
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "lame.h"

#define LS_A 0.051373
#define LS_B 0.0253235

// multimodal test problem with equidistant local Pareto fronts
double EMO_LS_natmin(double r) {
  return LS_B + r - LS_A + 0.5 + 0.5 * cos(2.0 * M_PI * (r - LS_A) + M_PI);  
}

// many-to-one mappings
double EMO_LS_ed2(double r) {
  return sin(r / M_PI);
}

void LS_init(int g_value, double gamma_value){
  switch(g_value) {
    case 0:  g_func = NULL;
             //printf("Lame Superspheres: unimodal\n");
             break;
    case 1:  g_func = &EMO_LS_natmin;
             //printf("Lame Superspheres: multimodal\n");
             break;
    case 2:  g_func = &EMO_LS_ed2;
             //printf("Lame Superspheres: many-to-one mappings\n");
             break;
    default: printf("Error, unknown value of %d for the lame_difficulty in the configuration file\n", g_value);
             exit(1);
  }
  gamma_ls = gamma_value;
}

// Lame Superspheres
void LAME(double *x, double *F, int n, int k, int *feval) {
  int i, j, m;
  double g, r;

  m = k;

  F[0] = cos(x[0]);
  F[0] = pow(F[0] * F[0], 1.0 / gamma_ls);

  // fj, j \in {1,..m-2} 
  for(j = m-2; j > 0; j--) {
    F[j] = 1.0;

    for(i = j-1; i > -1; i--)
      F[j] *= sin(x[i]);

    F[j] *= cos(x[j]);
    F[j] = pow(F[j] * F[j], 1.0 / gamma_ls);
  }

  F[m-1] = 1.0;

  for(i = m-2; i > -1; i--)
    F[m-1] *= sin(x[i]);

  F[m-1] = pow(F[m-1] * F[m-1], 1.0 / gamma_ls);

  r = 0.0;

  for(i = m-1; i < n; i++)
    r += x[i] * x[i];

  if(g_func == NULL)  // unimodal
    g = r;
  else
    g = g_func(r);

  for(i = 0; i < m; i++)
    F[i] *= (1.0 + g);

  (*feval)++;
}

// Lame Superspheres
void MIRROR(double *x, double *F, int n, int k, int *feval) {
  int i, j, m;
  double g, r;

  m = k;

  F[0] = cos(x[0]);
  F[0] = pow(F[0] * F[0], 1.0 / gamma_ls);

  // fj, j \in {1,..m-2} 
  for(j = m-2; j > 0; j--) {
    F[j] = 1.0;

    for(i = j-1; i > -1; i--)
      F[j] *= sin(x[i]);

    F[j] *= cos(x[j]);
    F[j] = pow(F[j] * F[j], 1.0 / gamma_ls);
  }

  F[m-1] = 1.0;

  for(i = m-2; i > -1; i--)
    F[m-1] *= sin(x[i]);

  F[m-1] = pow(F[m-1] * F[m-1], 1.0 / gamma_ls);

  r = 0.0;

  for(i = m-1; i < n; i++)
    r += x[i] * x[i];

  if(g_func == NULL)  // unimodal
    g = r;
  else
    g = g_func(r);

  for(i = 0; i < m; i++)
    F[i] = 1.0 - F[i] / (1.0 + g);

  (*feval)++;
}

#undef LS_A
#undef LS_B


