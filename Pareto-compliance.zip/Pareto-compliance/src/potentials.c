#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <limits.h>
//#include <omp.h>

#include "potentials.h"
#include "vector.h"

const char *EMO_PairPotentialList[] = {"RSE", "GAE", "COU", "PT", "MPT", "GPT", "KRA"};
const EMO_PairPotentialFunction ppfdic[] = {RSE, GAE, COU, PT, MPT, GPT, KRA};



void EMO_PP_allocate(PP_contribution *ppc, int n){
	if((ppc->cpp = (double *) malloc(n * sizeof(double))) == NULL){
		printf("Error! Not enough memory for array of s-energy contributions\n");
		exit(-1);
	}

	if((ppc->memoization = (double *) malloc(n * (n + 1) * sizeof(double))) == NULL){
		printf("Error! Not enough memory for memoization structure of s_energy\n");
		exit(-1);
	}

  /*int i;
  i = EMO_Dictionary_find(EMO_PairPotentialList, ppc->pname);
  if(i != -1){
    printf("Using %s as Pair-Potential Function\n", ppc->pname);
  }*/
  ppc->pp = ppfdic[0];    // ONLY USE RIESZ S-ENERGY

  //omp_set_num_threads(4);
}

void EMO_PP_free(PP_contribution *ppc){
	free(ppc->cpp);
	free(ppc->memoization);
}


double EMO_PP_matrix_computation(double *f,  int *filter, int n, int dim, PP_contribution *ppc, double (*pp)(double *, double *, double, int)){
  int i, j, size = 0;
  double Es = 0.0;
  //#pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux;
          aux = pp(f + j*dim, f + i*dim, dim - 1, dim);   // dim - 1 corresponds to the value of parameter s
          ppc->memoization[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      ppc->memoization[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}

double EMO_PP_update(double *cpp, int *filter, int n, int deleted){
  int i;
  double Es = 0.0;
  //#pragma omp parallel for private(i)
  for(i = 0; i < n; i++){
    if(filter[i]){
      cpp[i*(n + 1) + n] -= cpp[i*(n + 1) + deleted];
      Es += cpp[i*(n + 1) + n];
    }
  }
  return Es;
}

void EMO_PP_contribution(double Es, int *filter, int n, PP_contribution *ppc){
  int j, k;
  //#pragma omp parallel for private(j)
  for(k = 0; k < n; k++){
    if(filter[k]){
      double aux = 0.0;
      for(j = 0; j < n; j++){
        if(filter[j] && j != k){
          aux += ppc->memoization[j*(n + 1) + n] - ppc->memoization[j*(n + 1) + k];
        }
      }   
      ppc->cpp[k] = (Es - aux)/2.0;
    }
  }
}

int findMax2(double *data, int size, int *filter){
  int i, index = 0;
  double max = -DBL_MAX;
  for(i = 0; i < size; i++){
    if(filter[i] && data[i] > max){
      max = data[i];
      index = i;
    }
  }
  return index;
}

void EMO_PP_greedySelection(double *F, int *filter, int csize, int dsize, int nobj, PP_contribution *ppc, double (*pp)(double *, double *, double, int)){
	int aux_size = csize, index;
	double Es;
	Es = EMO_PP_matrix_computation(F, filter, csize, nobj, ppc, pp);
	while(aux_size > dsize){
		EMO_PP_contribution(Es, filter, csize, ppc);
		index = findMax2(ppc->cpp, csize, filter);
		filter[index] = 0;
		Es = EMO_PP_update(ppc->memoization, filter, csize, index);
		aux_size--;	
	}
}


double RSE(double *x, double *y, double s, int dim){
	double dist, K;
	dist = euclideanDistance(x, y, dim);
    if(dist == 0)
        dist = 1e-4;
    K = (s == 0.0)? log(1.0/dist) : pow(dist, -s); 
    return K; 

 
}

double GAE(double *x, double *y, double s, int dim){
	double dist, K;
	dist = euclideanDistance(x, y, dim);
     if(dist == 0)
        dist = 1e-4;
    K = exp(-s * dist * dist);
    return K;
}

double COU(double *x, double *y, double s, int dim){
	double dist, q1, q2, K;
	dist = euclideanDistance(x, y, dim);
    q1 = euclideanNorm(x, dim);
    q2 = euclideanNorm(y, dim);
    if(dist == 0)
        dist = 1e-4;
    K = 8.9875517873681764 * pow(10, 9) * q1 * q2 / (dist * dist);
    return K;
}

double PT(double *x, double *y, double s, int dim){
	double dist, K;
	dist = euclideanDistance(x, y, dim);
    if(dist == 0)
        dist = 1e-4;
    double V1 = 5.0;
    double V2 = 3.0;
    double alpha = 0.02;
    K = V1 / pow(sin(alpha * dist), 2) + V2 / pow(cos(alpha * dist), 2);
    return K;
}

double MPT(double *x, double *y, double s, int dim){
	double dist, K;
	dist = euclideanDistance(x, y, dim);
    if(dist == 0)
        dist = 1e-4;
    double alpha = 10.0;
    double D = 1.0;
    K = D / (cosh(alpha* dist) * cosh(alpha*dist));  
    return K; 
}

double GPT(double *x, double *y, double s, int dim){
	double dist, K;
	dist = euclideanDistance(x, y, dim);
    if(dist == 0)
        dist = 1e-4;
    K = 1 / (1 + cos(dist)) + 1 / (1 - cos(dist));
    return K;
}

double KRA(double *x, double *y, double s, int dim){
	double dist, K;
	dist = euclideanDistance(x, y, dim);
    if(dist == 0)
        dist = 1e-4;
    double V1 = 5.0;
    double V2 = 3.0;
    double alpha = 0.02;     
    K = V1 * pow((dist - 1.0/alpha) / dist, 2) + V2;
    return K;
}