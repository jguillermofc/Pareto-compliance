#ifndef __UTILITY_H__
#define __UTILITY_H__


typedef struct UTILITY 
{
	int nobj;

	double *z;	// Reference point
	double *znad;
	double alpha; // Penalty parameter of AASF
	double p_ewc;
	double p_vads;
	double theta_ipbi;
	double atch_alpha;


	double *vprime;
	double *wprime;

	double (*uf)(struct UTILITY *u, double *v, double *w);
}UTILITY;

typedef double (*UtilityFunction)(UTILITY *u, double *v, double *w);



void UTILITY_alloc(UTILITY *util, char *str, int dim);
void UTILITY_free(UTILITY *util);
int UTILITY_find(const char *dicc[], char *pattern);

double asf(UTILITY *util, double *v, double *w);
double aasf(UTILITY *util, double *v, double *w);
double vads(UTILITY *util, double *v, double *w);
double ewc(UTILITY *util, double *v, double *w);
double ipbi(UTILITY *util, double *v, double *w);
double atch(UTILITY *u, double *x, double *w);
double wn(UTILITY *u, double *x, double *w);
double ws(UTILITY *u, double *x, double *w);

#endif
