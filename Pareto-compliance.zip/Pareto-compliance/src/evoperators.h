#ifndef __EVOPERATORS_H__
#define __EVOPERATORS_H__

#include "mop.h"
#include "Rand.h"

#define REAL 1
#define BINARY 0

void crossSBX(EMO_Rand *random, double *child1, double *child2, double *parent1, double *parent2, MOP *mop, double Pc, double eta_c);
void mutatePolynom(EMO_Rand *random, double *child, MOP *mop, double Pm, double eta_m);



#endif