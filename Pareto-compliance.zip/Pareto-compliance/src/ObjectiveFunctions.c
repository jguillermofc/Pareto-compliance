


#include "ObjectiveFunctions.h"

#define K_DTLZ1 5
#define K_DTLZ2_6 10
#define K_DTLZ7 20
#define N_ZDT 24
#define N_VIE 2
#define N_UF 30

void findfunc(char *nom, void (**apf)(double *, double *, int, int, int *)) {

  char *name[] = {"ZDT1", "ZDT2", "ZDT3", "ZDT4", "ZDT6",
                  "DTLZ1", "DTLZ2", "DTLZ3","DTLZ4", 
                  "DTLZ5", "DTLZ6", "DTLZ7",
                  "WFG1", "WFG2", "WFG3", "WFG4", "WFG5", "WFG6",
                  "WFG7", "WFG8", "WFG9",
                  "DTLZ1_MINUS", "DTLZ2_MINUS", "DTLZ3_MINUS","DTLZ4_MINUS", 
                  "DTLZ5_MINUS", "DTLZ6_MINUS", "DTLZ7_MINUS",
                  "WFG1_MINUS", "WFG2_MINUS", "WFG3_MINUS", "WFG4_MINUS", "WFG5_MINUS", "WFG6_MINUS",
                  "WFG7_MINUS", "WFG8_MINUS", "WFG9_MINUS",
                  "VIE1", "VIE2", "VIE3",
                  "UF1", "UF2", "UF3", "UF4", "UF5", "UF6", "UF7", "UF8", "UF9", "UF10",
                  "LAME", "MIRROR",


                  "WFG1_UNS", "WFG1_UNN",
                  "WFG1_UPS", "WFG1_UPN",
                  "WFG1_UFS", "WFG1_UFN",
                  "WFG1_UDS", "WFG1_UDN",

                  "WFG1_MNS", "WFG1_MNN",
                  "WFG1_MPS", "WFG1_MPN",
                  "WFG1_MFS", "WFG1_MFN",
                  "WFG1_MDS", "WFG1_MDN",

                  "WFG1_DNS", "WFG1_DNN",
                  "WFG1_DPS", "WFG1_DPN",
                  "WFG1_DFS", "WFG1_DFN",
                  "WFG1_DDS", "WFG1_DDN",



                  "WFG2_UNS", "WFG2_UNN",
                  "WFG2_UPS", "WFG2_UPN",
                  "WFG2_UFS", "WFG2_UFN",
                  "WFG2_UDS", "WFG2_UDN",

                  "WFG2_MNS", "WFG2_MNN",
                  "WFG2_MPS", "WFG2_MPN",
                  "WFG2_MFS", "WFG2_MFN",
                  "WFG2_MDS", "WFG2_MDN",

                  "WFG2_DNS", "WFG2_DNN",
                  "WFG2_DPS", "WFG2_DPN",
                  "WFG2_DFS", "WFG2_DFN",
                  "WFG2_DDS", "WFG2_DDN",



                  "WFG3_UNS", "WFG3_UNN",
                  "WFG3_UPS", "WFG3_UPN",
                  "WFG3_UFS", "WFG3_UFN",
                  "WFG3_UDS", "WFG3_UDN",

                  "WFG3_MNS", "WFG3_MNN",
                  "WFG3_MPS", "WFG3_MPN",
                  "WFG3_MFS", "WFG3_MFN",
                  "WFG3_MDS", "WFG3_MDN",

                  "WFG3_DNS", "WFG3_DNN",
                  "WFG3_DPS", "WFG3_DPN",
                  "WFG3_DFS", "WFG3_DFN",
                  "WFG3_DDS", "WFG3_DDN",



                  "WFG4_UNS", "WFG4_UNN",
                  "WFG4_UPS", "WFG4_UPN",
                  "WFG4_UFS", "WFG4_UFN",
                  "WFG4_UDS", "WFG4_UDN",

                  "WFG4_MNS", "WFG4_MNN",
                  "WFG4_MPS", "WFG4_MPN",
                  "WFG4_MFS", "WFG4_MFN",
                  "WFG4_MDS", "WFG4_MDN",

                  "WFG4_DNS", "WFG4_DNN",
                  "WFG4_DPS", "WFG4_DPN",
                  "WFG4_DFS", "WFG4_DFN",
                  "WFG4_DDS", "WFG4_DDN",




                  "WFG5_UNS", "WFG5_UNN",
                  "WFG5_UPS", "WFG5_UPN",
                  "WFG5_UFS", "WFG5_UFN",
                  "WFG5_UDS", "WFG5_UDN",

                  "WFG5_MNS", "WFG5_MNN",
                  "WFG5_MPS", "WFG5_MPN",
                  "WFG5_MFS", "WFG5_MFN",
                  "WFG5_MDS", "WFG5_MDN",

                  "WFG5_DNS", "WFG5_DNN",
                  "WFG5_DPS", "WFG5_DPN",
                  "WFG5_DFS", "WFG5_DFN",
                  "WFG5_DDS", "WFG5_DDN",




                  "WFG6_UNS", "WFG6_UNN",
                  "WFG6_UPS", "WFG6_UPN",
                  "WFG6_UFS", "WFG6_UFN",
                  "WFG6_UDS", "WFG6_UDN",

                  "WFG6_MNS", "WFG6_MNN",
                  "WFG6_MPS", "WFG6_MPN",
                  "WFG6_MFS", "WFG6_MFN",
                  "WFG6_MDS", "WFG6_MDN",

                  "WFG6_DNS", "WFG6_DNN",
                  "WFG6_DPS", "WFG6_DPN",
                  "WFG6_DFS", "WFG6_DFN",
                  "WFG6_DDS", "WFG6_DDN",

                };

  void (*fdic[])(double *, double *, int, int , int *) = {
                   ZDT1, ZDT2, ZDT3, ZDT4, ZDT6,
                   DTLZ1, DTLZ2, DTLZ3, DTLZ4, DTLZ5,
                   DTLZ6, DTLZ7,
                   wfg1, wfg2, wfg3, wfg4, wfg5, wfg6, 
                   wfg7, wfg8, wfg9,
                   DTLZ1_MINUS, DTLZ2_MINUS, DTLZ3_MINUS, DTLZ4_MINUS,
                   DTLZ5_MINUS, DTLZ6_MINUS, DTLZ7_MINUS,
                   wfg1_minus, wfg2_minus, wfg3_minus, wfg4_minus, 
                   wfg5_minus, wfg6_minus, wfg7_minus, wfg8_minus, wfg9_minus,
                   VIE1, VIE2, VIE3,
                   UF1, UF2, UF3, UF4, UF5, UF6, UF7, UF8, UF9, UF10,
                   LAME, MIRROR,
                   // WFG1 shape
                   wfg1_UNS, wfg1_UNN,
                   wfg1_UPS, wfg1_UPN,
                   wfg1_UFS, wfg1_UFN,
                   wfg1_UDS, wfg1_UDN,

                   wfg1_MNS, wfg1_MNN,
                   wfg1_MPS, wfg1_MPN,
                   wfg1_MFS, wfg1_MFN,
                   wfg1_MDS, wfg1_MDN,

                   wfg1_DNS, wfg1_DNN,
                   wfg1_DPS, wfg1_DPN,
                   wfg1_DFS, wfg1_DFN,
                   wfg1_DDS, wfg1_DDN,

                   // WFG2 shape
                   wfg2_UNS, wfg2_UNN,
                   wfg2_UPS, wfg2_UPN,
                   wfg2_UFS, wfg2_UFN,
                   wfg2_UDS, wfg2_UDN,

                   wfg2_MNS, wfg2_MNN,
                   wfg2_MPS, wfg2_MPN,
                   wfg2_MFS, wfg2_MFN,
                   wfg2_MDS, wfg2_MDN,

                   wfg2_DNS, wfg2_DNN,
                   wfg2_DPS, wfg2_DPN,
                   wfg2_DFS, wfg2_DFN,
                   wfg2_DDS, wfg2_DDN,

                   // WFG3 shape
                   wfg3_UNS, wfg3_UNN,
                   wfg3_UPS, wfg3_UPN,
                   wfg3_UFS, wfg3_UFN,
                   wfg3_UDS, wfg3_UDN,

                   wfg3_MNS, wfg3_MNN,
                   wfg3_MPS, wfg3_MPN,
                   wfg3_MFS, wfg3_MFN,
                   wfg3_MDS, wfg3_MDN,

                   wfg3_DNS, wfg3_DNN,
                   wfg3_DPS, wfg3_DPN,
                   wfg3_DFS, wfg3_DFN,
                   wfg3_DDS, wfg3_DDN,


                   // WFG4 shape CONCAVE
                   wfg4_UNS, wfg4_UNN,
                   wfg4_UPS, wfg4_UPN,
                   wfg4_UFS, wfg4_UFN,
                   wfg4_UDS, wfg4_UDN,

                   wfg4_MNS, wfg4_MNN,
                   wfg4_MPS, wfg4_MPN,
                   wfg4_MFS, wfg4_MFN,
                   wfg4_MDS, wfg4_MDN,

                   wfg4_DNS, wfg4_DNN,
                   wfg4_DPS, wfg4_DPN,
                   wfg4_DFS, wfg4_DFN,
                   wfg4_DDS, wfg4_DDN,



                   // WFG5 shape CONVEX
                   wfg5_UNS, wfg5_UNN,
                   wfg5_UPS, wfg5_UPN,
                   wfg5_UFS, wfg5_UFN,
                   wfg5_UDS, wfg5_UDN,

                   wfg5_MNS, wfg5_MNN,
                   wfg5_MPS, wfg5_MPN,
                   wfg5_MFS, wfg5_MFN,
                   wfg5_MDS, wfg5_MDN,

                   wfg5_DNS, wfg5_DNN,
                   wfg5_DPS, wfg5_DPN,
                   wfg5_DFS, wfg5_DFN,
                   wfg5_DDS, wfg5_DDN,



                   // WFG6 shape LINEAR
                   wfg6_UNS, wfg6_UNN,
                   wfg6_UPS, wfg6_UPN,
                   wfg6_UFS, wfg6_UFN,
                   wfg6_UDS, wfg6_UDN,

                   wfg6_MNS, wfg6_MNN,
                   wfg6_MPS, wfg6_MPN,
                   wfg6_MFS, wfg6_MFN,
                   wfg6_MDS, wfg6_MDN,

                   wfg6_DNS, wfg6_DNN,
                   wfg6_DPS, wfg6_DPN,
                   wfg6_DFS, wfg6_DFN,
                   wfg6_DDS, wfg6_DDN,

                };
  int i = 0;

  while(name[i] != NULL) {

    if(strcmp(nom, name[i]) == 0) {
      *apf = fdic[i];
      return;
    }
    i++;
  }
  *apf = fdic[0]; // Set the first POM as default
}

void ZDT1(double *x, double *F, int n, int k, int *feval){
  double f1, f2, g, h;
  int i;
  f1 = x[0];
  g = 0.0;
  for (i = 1; i < n; i++) {
    g += x[i];
  }
  g = 9.0 * g / (n - 1);
  g += 1.0;
  h = 1.0 - sqrt(f1 / g);
  f2 = g * h;
  F[0] = f1;
  F[1] = f2;
  (*feval)++;
  return;
}


void ZDT2(double *x, double *F, int n, int k, int *feval) {
    double f1, f2, g, h;
    int i;
    f1 = x[0];
    g = 0;
    for(i = 1; i < n; i++)
      g += x[i];

    g = 9.0 * g / (n - 1.0);
    g += 1;
    h = 1 - pow((f1/g), 2);
    f2 = g * h;
    F[0] = f1;
    F[1] = f2;
    (*feval)++;
    return;
}


void ZDT3(double *x, double *F, int n, int k, int *feval){
  double f1, f2, g, h;
  int i;
  f1 = x[0];
  g = 0.0;
  for (i = 1; i < n; i++) {
    g += x[i];
  }
  g = 9.0 * g / (n - 1.0);
  g += 1.0;
  h = 1.0 - sqrt(f1 / g) - (f1 / g) * sin(10.0 * M_PI * f1);
  f2 = g * h;
  F[0] = f1;
  F[1] = f2;
  (*feval)++;
  return;
}

void ZDT4(double *x, double *F, int n, int k, int *feval){
  double f1, f2, g, h, sum;
  int j;

  f1 = x[0];
  sum = 0.0;
  for (j = 1; j < n; j++) {
    sum += (pow(x[j], 2.0) - 10.0 * cos(4.0 * M_PI * x[j]));
  }
  g = 1.0 + 10.0 * (n - 1.0) + sum;
  h = 1.0 - sqrt(f1 / g);
  f2 = g * h;
  F[0] = f1;
  F[1] = f2;
  (*feval)++;
  return;
}

void ZDT6(double *x, double *F, int n, int k, int *feval) {
    double f1, f2, g, h;
    int i;

    f1 = 1 - (exp(-4.0 * x[0])) * pow((sin(6.0 * M_PI * x[0])), 6);
    g = 0;

    for(i = 1; i < n; i++)
      g += x[i];

    g = g/9;
    g = pow(g, 0.25);
    g = 1 + 9*g;
    h = 1 - pow((f1/g),2);
    f2 = g * h;
    F[0] = f1;
    F[1] = f2;
    (*feval)++;
  return;
}


void DTLZ1(double *x, double *F, int n, int k, int *feval) {
  double g;
  int i, j, t, c;

  g = 0;
  c = n - k + 1;

  for(i = n - c; i < n; i++)
    g += pow(x[i] - 0.5, 2) - cos(20*M_PI*(x[i] - 0.5));

  g = 100*(c + g);

  for(i = 0; i < k; i++) {
    F[i] = 0.5*(1 + g);

    t = k - i - 1; 

    for(j = 0; j < t; j++) {
      F[i] *= x[j];
    }

    if(t < k - 1) {
      F[i] *= (1 - x[t]);
    }
  }
  (*feval)++;
}


void DTLZ2(double *x, double *F, int n, int k, int *feval) {
  double g;
  int i, j, t, c;

  g = 0;
  c = n - k + 1;

  for(i = n - c; i < n; i++)
    g += pow(x[i] - 0.5, 2);


  for(i = 0; i < k; i++) {
    F[i] = (1 + g);

    t = k - i - 1; 

    for(j = 0; j < t; j++) {
      F[i] *= cos(x[j]*M_PI*0.5);
    }

    if(t < k - 1) {
      F[i] *= sin(x[t]*M_PI*0.5);
    }
  }
  (*feval)++;
}


void DTLZ3(double *x, double *F, int n, int k, int *feval) {
  double g;
  int i, j, t, c;

  g = 0;
  c = n - k + 1;

  for(i = n - c; i < n; i++)
    g += pow(x[i] - 0.5, 2) - cos(20*M_PI*(x[i] - 0.5));

  g = 100*(c + g);

  for(i = 0; i < k; i++) {
    F[i] = (1 + g);

    t = k - i - 1; 

    for(j = 0; j < t; j++) {
      F[i] *= cos(x[j]*M_PI*0.5);
    }

    if(t < k - 1) {
      F[i] *= sin(x[t]*M_PI*0.5);
    }
  }
  (*feval)++;
}


void DTLZ4(double *x, double *F, int n, int k, int *feval) {
  double g, alpha = 100;
  int i, j, t, c;

  g = 0;
  c = n - k + 1;

  for(i = n - c; i < n; i++)
    g += pow(x[i] - 0.5, 2);


  for(i = 0; i < k; i++) {
    F[i] = (1 + g);

    t = k - i - 1; 

    for(j = 0; j < t; j++) {
      F[i] *= cos(pow(x[j], alpha)*M_PI*0.5);
    }

    if(t < k - 1) {
      F[i] *= sin(pow(x[t], alpha)*M_PI*0.5);
    }
  }
  (*feval)++;
}


void DTLZ5(double *x, double *F, int n, int k, int *feval) {
  double g, *theta, p;
  int i, j, t, c;

  theta = (double *) malloc(sizeof(double) * (k - 1));
  g = 0;
  c = n - k + 1;

  for(i = n - c; i < n; i++)
    g += pow(x[i] - 0.5, 2);

  theta[0] = x[0] * M_PI * 0.5;
  p = M_PI / (4 * (1 + g));

  for(i = 1; i < k - 1; i++)
    theta[i] = p * (1 + 2 * g * x[i]);

  for(i = 0; i < k; i++) {
    F[i] = (1 + g);

    t = k - i - 1; 

    for(j = 0; j < t; j++) {
      F[i] *= cos(theta[j]);
    }

    if(t < k - 1) {
      F[i] *= sin(theta[t]);
    }
  }

  free(theta);
  (*feval)++;
}

void DTLZ6(double *x, double *F, int n, int k, int *feval){
  
  double g, *theta, p;
    int i, j, t, c;

    theta = (double *) malloc(sizeof(double) * (k-1));
    g = 0;
    c = n - k + 1;

    for(i = n - c; i < n; i++)
      g += pow(x[i], 0.1);

    theta[0] = x[0] * M_PI * 0.5;
    p = M_PI / (4 * (1 + g));

    for(i = 1; i < k-1; i++)
      theta[i] = p * (1 + 2 * g * x[i]);

    for(i = 0; i < k; i++) {
      F[i] = (1 + g);

      t = k - i - 1; 

      for(j = 0; j < t; j++) {
          F[i] *= cos(theta[j]);
      }

      if(t < k - 1) {
          F[i] *= sin(theta[t]);
      }
    } 

    free(theta);
    (*feval)++;

  return; 
}


void DTLZ7(double *x, double *F, int n, int k, int *feval) {
  double g, h;
  int i, c;

  g = h = 0;
  c = n - k + 1;

  for(i = 0; i < k - 1; i++) 
    F[i] = x[i];

  for(i = n - c; i < n; i++)
    g += x[i];

  g = 1 + 9 * g / c;

  for(i = 0; i < k - 1; i++)
    h += x[i] / (1 + g) * (1 + sin(3*M_PI*x[i]));

  h = k - h;

  F[k-1] = (1 + g) * h;
  (*feval)++;
}

void DTLZ1_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ1(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}

void DTLZ2_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ2(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}

void DTLZ3_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ3(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}

void DTLZ4_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ4(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}

void DTLZ5_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ5(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}

void DTLZ6_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ6(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}

void DTLZ7_MINUS(double *x, double *F, int n, int k, int *feval){
  int i;
  DTLZ7(x, F, n, k, feval);
  for(i = 0; i < k; i++)
    F[i] *= -1.0;
}


/* Test problem VIE1 (Viennet, 1996)

   Real variables = 2 
   Bin variables = 0
   Objectives = 3
   Constraints = 0
   Values of x are in [-2,2]
   POS connected and symmetric, PFTrue curved surface
*/
void VIE1(double *x, double *F, int n, int k, int *feval) {
  double a;

  a = x[0] * x[0];

  F[0] = a + pow(x[1] - 1.0, 2.0);
  F[1] = a + pow(x[1] + 1.0, 2.0) + 1.0;
  F[2] = pow(x[0] - 1.0, 2.0) + x[1] * x[1] + 2.0;
  (*feval)++;
}



/* Test problem VIE2 (Viennet, 1996)

   Real variables = 2 
   Bin variables = 0
   Objectives = 3
   Constraints = 0
   Values of x are in [-4,4]
   POS connected, PFTrue disconnected
*/
void VIE2(double *x, double *F, int n, int k, int *feval) {
  F[0] = pow(x[0] - 2.0, 2.0) * 0.5 + pow(x[1] + 1.0, 2.0) / 13.0 + 3.0;
  F[1] = pow(x[0] + x[1] - 3.0, 2.0) / 36.0 + pow(-x[0] + x[1] + 2.0, 2.0) * 0.125 - 17.0;
  F[2] = pow(x[0] + 2.0 * x[1] - 1.0, 2.0) / 175.0 + pow(2.0 * x[1] - x[0], 2.0) / 17.0 - 13.0;
  (*feval)++;
}

/* Test problem VIE3 (Viennet, 1996)

   Real variables = 2 
   Bin variables = 0
   Objectives = 3
   Constraints = 0
   Values of x are in [-3,3]
   POS disconnected and unsymmetric, PFTrue connected
*/
void VIE3(double *x, double *F, int n, int k, int *feval) {
  double a;

  a = x[0] * x[0] + x[1] * x[1];
 
  F[0] = 0.5 * a + sin(a);
  F[1] = pow(3.0 * x[0] - 2.0 * x[1] + 4.0, 2.0) * 0.125 + pow(x[0] - x[1] + 1.0, 2.0) / 27.0 + 15.0;
  F[2] = 1.0 / (a + 1.0) - 1.1 * exp(-a);
  (*feval)++;
}



/* Test problem UF1

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1] x [-1,1]^(n-1)
   PFTrue is at f2 = 1 - sqrt(f1), f1 in [0,1]
                xj = sin(6*PI*x1 + j*PI/n), j = 2,...,n 0 <= x1 <= 1
   Convex Pareto-optimal front
*/
void UF1(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, yj;

  sum1   = sum2   = 0.0;
  count1 = count2 = 0;

  for(j = 2; j <= n; j++) {
    yj = x[j-1] - sin(6.0 * PI * x[0] + j * PI / (double) n);
    yj = yj * yj;

    if(j % 2 == 0) {
      sum2 += yj;
      count2++;
    } 
    else {
      sum1 += yj;
      count1++;
    }
  }

  F[0] = x[0] + 2.0 * sum1 / (double) count1;
  F[1] = 1.0 - sqrt(x[0]) + 2.0 * sum2 / (double) count2;
  (*feval)++;
}

/* Test problem UF2

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1]x[-1,1]^(n-1)
   PFTrue is at f2 = 1 - sqrt(f1), f1 in [0, 1]
   xj = {(0.3*x1^2*cos(24*PI*x[0]+4*j*PI/n)+0.6*x[0])*cos(6*PI*x[0]+j*PI/n) j in J1
         (0.3*x1^2*cos(24*PI*x[0]+4*j*PI/n)+0.6*x[0])*sin(6*PI*x[0]+j*PI/n) j in J2
        0 <= x <= 1
   Convex Pareto-optimal front
*/
void UF2(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, yj;

  sum1   = sum2   = 0.0;
  count1 = count2 = 0;

  for(j = 2; j <= n; j++) {
    if(j % 2 == 0) {
      yj = x[j-1]-0.3*x[0]*(x[0]*cos(24.0*PI*x[0]+4.0*j*PI/(double) n)+2.0)*sin(6.0*PI*x[0]+j*PI/(double) n);
      sum2 += yj*yj;
      count2++;
    }
    else {
      yj = x[j-1]-0.3*x[0]*(x[0]*cos(24.0*PI*x[0]+4.0*j*PI/(double) n)+2.0)*cos(6.0*PI*x[0]+j*PI/(double) n);
      sum1 += yj*yj;
      count1++;
    }
  }

  F[0] = x[0] + 2.0 * sum1 / (double)count1;
  F[1] = 1.0 - sqrt(x[0]) + 2.0 * sum2 / (double)count2;
  (*feval)++;
}

/* Test problem UF3

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1]^n
   PFTrue is at f2 = 1 - sqrt(f1), f1 in [0, 1]
   xj = x1^(0.5*(1+3*(j-2) / (n-2))) j = 2,...,n 0 <= x1 <= 1
   Convex Pareto-optimal front
*/
void UF3(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, prod1, prod2, yj, pj;

  sum1   = sum2   = 0.0;
  count1 = count2 = 0;
  prod1  = prod2  = 1.0;

  for(j = 2; j <= n; j++) {
    yj = x[j-1] - pow(x[0], 0.5 * (1.0 + 3.0 * (j - 2.0) / ((double) n - 2.0)));
    pj = cos(20.0 * yj * PI / sqrt((double) j));

    if (j % 2 == 0) {
      sum2  += yj*yj;
      prod2 *= pj;
      count2++;
    } 
    else {
      sum1  += yj*yj;
      prod1 *= pj;
      count1++;
    }
  }

  F[0] = x[0] + 2.0 * (4.0 * sum1 - 2.0 * prod1 + 2.0) / ((double) count1);
  F[1] = 1.0 - sqrt(x[0]) + 2.0 * (4.0 * sum2 - 2.0 * prod2 + 2.0) / ((double) count2);
  (*feval)++;
}

/* Test problem UF4

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1] x [-2,2]^(n-1)
   PFTrue is at f2 = 1 - f1^2, f1 in [0, 1]
                xj = sin(6*PI*x[0] + j * PI/n), j = 2,...,n 0 <= x1 <= 1
   Concave Pareto-optimal front
*/
void UF4(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, yj, hj;

  sum1   = sum2   = 0.0;
  count1 = count2 = 0;

  for(j = 2; j <= n; j++) {
    yj = x[j-1] - sin(6.0 * PI * x[0] + j * PI / (double) n);
    hj = fabs(yj) / (1.0 + exp(2.0 * fabs(yj)));

    if (j % 2 == 0) {
      sum2 += hj;
      count2++;
    } 
    else {
      sum1 += hj;
      count1++;
    }
  }

  F[0] = x[0] + 2.0 * sum1 / (double)count1;
  F[1] = 1.0 - x[0] * x[0] + 2.0 * sum2 / (double)count2;
  (*feval)++;
}
 
/* Test problem UF5

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1] x [-1,1]^(n-1)
   PF has 2N+1 Pareto Optimal solutions: (i/(2N),1-i/(2N))
   Disconnected and linear Pareto-optimal front
*/
void UF5(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, yj, hj, N, E;

  sum1   = sum2   = 0.0;
  count1 = count2 = 0;
  N = 10.0; E = 0.1;

  for(j = 2; j <= n; j++) {
    yj = x[j-1] - sin(6.0 * PI * x[0] + j * PI / (double) n);
    hj = 2.0 * yj * yj - cos(4.0 * PI * yj) + 1.0;

    if (j % 2 == 0) {
      sum2  += hj;
      count2++;
    } 
    else {
      sum1  += hj;
      count1++;
    }
  }

  hj = (0.5 / N + E) * fabs(sin(2.0 * N * PI * x[0]));
  F[0] = x[0] + hj + 2.0 * sum1 / (double)count1;
  F[1] = 1.0 - x[0] + hj + 2.0 * sum2 / (double)count2;
  (*feval)++;
}

/* Test problem UF6

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1] x [-1,1]^(n-1)
   PFTrue is at f2 = 1 - f1, f1 in Union_{i=1}^{N} [(2i-1)/2N, 2i/2N]
   Disconnected Pareto-optimal front
*/
void UF6(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, prod1, prod2, yj, hj, pj, N, E;

  N = 2.0; E = 0.1;
  sum1   = sum2   = 0.0;
  count1 = count2 = 0;
  prod1  = prod2  = 1.0;

  for(j = 2; j <= n; j++) {

    yj = x[j-1] - sin(6.0 * PI * x[0] + j * PI / (double) n);
    pj = cos(20.0 * yj * PI / sqrt((double) j));

    if (j % 2 == 0) {
      sum2  += yj * yj;
      prod2 *= pj;
      count2++;
    }
    else {
      sum1  += yj * yj;
      prod1 *= pj;
      count1++;
    }
  }

  hj = 2.0 * (0.5 / N + E) * sin(2.0 * N * PI * x[0]);

  if(hj < 0.0) hj = 0.0;

  F[0] = x[0] + hj + 2.0 * (4.0 * sum1 - 2.0 * prod1 + 2.0) / (double)count1;
  F[1] = 1.0 - x[0] + hj + 2.0 * (4.0 * sum2 - 2.0 * prod2 + 2.0) / (double)count2;
  (*feval)++;
}

/* Test problem UF7

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 2
   Constraints = 0
   Values of x are in [0,1] x [-1,1]^(n-1)
   PFTrue is at f2 = 1 - f1, f1 in [0,1]
                xj = sin(6*PI*x[0] + j*PI/n), j = 2,...,n, x1 in [0,1]
   Linear Pareto-optimal front
*/
void UF7(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2;
  double sum1, sum2, yj;

  sum1   = sum2   = 0.0;
  count1 = count2 = 0;

  for(j = 2; j <= n; j++) {
    yj = x[j-1] - sin(6.0 * PI * x[0] + j * PI / (double) n);

    if (j % 2 == 0) {
      sum2  += yj * yj;
      count2++;
    } 
    else {
      sum1  += yj * yj;
      count1++;
    }
  }

  yj = pow(x[0], 0.2);

  F[0] = yj + 2.0 * sum1 / (double) count1;
  F[1] = 1.0 - yj + 2.0 * sum2 / (double) count2;
  (*feval)++;
}

/* Test problem UF8

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 3
   Constraints = 0
   Values of x are in [0,1]^2 x [-2,2]^(n-2)
   PFTrue is at f1^2 + f2^2 + f3^2 = 1, 0 <= f1,f2,f3 <= 1
   xj = 2*x2*sin(2*PI*x1 + j*PI/n), j = 3,...,n
   Concave Pareto-optimal front
*/
void UF8(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2, count3;
  double sum1, sum2, sum3, yj;

  sum1   = sum2   = sum3   = 0.0;
  count1 = count2 = count3 = 0;

  for(j = 3; j <= n; j++) {
    yj = x[j-1] - 2.0 * x[1] * sin(2.0 * PI * x[0] + j * PI / (double) n);

    if(j % 3 == 1) {
      sum1  += yj * yj;
      count1++;
    }
    else if(j % 3 == 2) {
      sum2  += yj * yj;
      count2++;
    }
    else {
      sum3  += yj * yj;
      count3++;
    }
  }

  F[0] = cos(0.5*PI*x[0]) * cos(0.5*PI*x[1]) + 2.0 * sum1 / (double)count1;
  F[1] = cos(0.5*PI*x[0]) * sin(0.5*PI*x[1]) + 2.0 * sum2 / (double)count2;
  F[2] = sin(0.5*PI*x[0]) + 2.0 * sum3 / (double)count3;
  (*feval)++;
}

/* Test problem UF9

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 3
   Constraints = 0
   Values of x are in [0,1]^2 x [-2,2]^(n-2)
   PFTrue has two parts. The first part is
      0 <= f3 <= 1, 0 <= f1 <= 1/4 (1 - f3), f2 = 1 - f1 - f3
   and the second one is
      0 <= f3 <= 1, 3/4 (1 - f3) <= f1 <= 1, f2 = 1 - f1 - f3
   The PS also has two disconnected parts:
      x1 in [0,0.25] Union [0.75,1], 0 <= x2 <= 1,
      xj = 2*x2*sin(2*PI*x1 + j*PI/n), j = 3,...,n
   Disconnected Pareto-optimal front
*/
void UF9(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2, count3;
  double sum1, sum2, sum3, yj, E;

  E = 0.1;
  sum1   = sum2   = sum3   = 0.0;
  count1 = count2 = count3 = 0;

  for(j = 3; j <= n; j++) {
    yj = x[j-1] - 2.0 * x[1] * sin(2.0 * PI * x[0] + j * PI / (double) n);

    if(j % 3 == 1) {
      sum1  += yj * yj;
      count1++;
    } 
    else if(j % 3 == 2) {
      sum2  += yj * yj;
      count2++;
    } 
    else {
      sum3  += yj * yj;
      count3++;
    }
  }

  yj = (1.0 + E) * (1.0 - 4.0 * (2.0 * x[0] - 1.0) * (2.0 * x[0] - 1.0));

  if(yj < 0.0) yj = 0.0;

  F[0] = 0.5 * (yj + 2.0 * x[0]) * x[1] + 2.0 * sum1 / (double)count1;
  F[1] = 0.5 * (yj - 2.0 * x[0] + 2.0) * x[1] + 2.0 * sum2 / (double)count2;
  F[2] = 1.0 - x[1] + 2.0 * sum3 / (double)count3;
  (*feval)++;
}

/* Test problem UF10

   Real variables = 30 (scalable)
   Bin variables = 0
   Objectives = 3
   Constraints = 0
   Values of x are in [0,1]^2 x [-2,2]^(n-2)
   PFTrue is f1^2 + f2^2 + f3^2 = 1, 0 <= f1,f2,f3 <= 1
             xj = 2*x2*sin(2*PI*x1 + j*PI/n), j = 3,...,n
   Concave Pareto-optimal front
*/
void UF10(double *x, double *F, int n, int k, int *feval) {
  int j, count1, count2, count3;
  double sum1, sum2, sum3, yj, hj;

  sum1   = sum2   = sum3   = 0.0;
  count1 = count2 = count3 = 0;

  for(j = 3; j <= n; j++) {
    yj = x[j-1] - 2.0 * x[1] * sin(2.0 * PI * x[0] + j * PI / (double) n);
    hj = 4.0 * yj * yj - cos(8.0 * PI * yj) + 1.0;

    if(j % 3 == 1) {
      sum1  += hj;
      count1++;
    }
    else if(j % 3 == 2) {
      sum2  += hj;
      count2++;
    }
    else {
      sum3  += hj;
      count3++;
    }
  }

  F[0] = cos(0.5*PI*x[0]) * cos(0.5*PI*x[1]) + 2.0 * sum1 / (double)count1;
  F[1] = cos(0.5*PI*x[0]) * sin(0.5*PI*x[1]) + 2.0 * sum2 / (double)count2;
  F[2] = sin(0.5*PI*x[0]) + 2.0 * sum3 / (double) count3;
  (*feval)++;
}

void defaultVariables(char *name, int nobj, int *nvar){
  if(strncmp(name, "VIE", 3) == 0){
    *nvar = N_VIE;
  }else if(strncmp(name, "UF", 2) == 0){
    *nvar = N_UF;
  }else if(strncmp(name, "ZDT", 3) == 0){
    *nvar = N_ZDT;
  }else if(strncmp(name, "DTLZ1", 5) == 0 || strcmp(name, "LAME") == 0 || strcmp(name, "MIRROR") == 0)
    *nvar = K_DTLZ1 + nobj - 1;
  else if(!strncmp(name, "DTLZ2", 5) || !strncmp(name, "DTLZ3", 5) || !strncmp(name, "DTLZ4", 5) || !strncmp(name, "DTLZ5", 5) || !strncmp(name, "DTLZ6", 5))
    *nvar = K_DTLZ2_6 + nobj - 1;
  else if(!strncmp(name, "DTLZ7", 5))
    *nvar = K_DTLZ7 + nobj - 1;
}


void defaultBoxConstraints(char *name, double *xmin, double *xmax, int nvar, int nobj){
  int i;
  if(strcmp(name, "LAME") == 0 || strcmp(name, "MIRROR") == 0){
    for(i = 0; i < nobj - 1; i++) {
      xmin[i] = 0.0;
      xmax[i] = PI / 2.0;
    }

    for(i = nobj - 1; i < nvar; i++) {
      xmin[i] = 0.0;
      xmax[i] = 1.0;
    }
  }else if(strcmp(name, "VIE1") == 0){
    for(i = 0; i < nvar; i++){
      xmin[i] = -2.0;
      xmax[i] = 2.0;
    }
  }else if(strcmp(name, "VIE2") == 0){
    for(i = 0; i < nvar; i++){
      xmin[i] = -4.0;
      xmax[i] = 4.0;
    }
  }else if(strcmp(name, "VIE3") == 0){
    for(i = 0; i < nvar; i++){
      xmin[i] = -3.0;
      xmax[i] = 3.0;
    }
  }else if(strcmp(name, "UF1") == 0 || strcmp(name, "UF2") == 0 || strcmp(name, "UF5") == 0 || strcmp(name, "UF6") == 0 || strcmp(name, "UF7") == 0){
    xmin[0] = 0.0;
    xmax[0] = 1.0;

    for(i = nvar - 1; i > 0; i--) {
      xmin[i] = -1.0;
      xmax[i] =  1.0;
    }
  }else if(strcmp(name, "UF8") == 0 || strcmp(name, "UF9") == 0 || strcmp(name, "UF10") == 0){
    xmin[0] = xmin[1] = 0.0;
    xmax[0] = xmax[1] = 1.0;

    for(i = nvar - 1; i > 1; i--) {
      xmin[i] = -2.0;
      xmax[i] = 2.0;
    }
  }else if(strcmp(name, "UF3") == 0){
    for(i = 0; i < nvar; i++){
      xmin[i] = 0.0;
      xmin[i] = 1.0;
    }
  }else if(strcmp(name, "UF4") == 0){
    xmin[0] = 0.0;
    xmax[0] = 1.0;
    for(i = nvar - 1; i > 0; i--) {
      xmin[i] = -2.0;
      xmax[i] =  2.0;
    }
  }else{
    for(i = 0; i < nvar; i++){
      xmin[i] = 0.0;
      xmax[i] = 1.0;
    }
  }
}