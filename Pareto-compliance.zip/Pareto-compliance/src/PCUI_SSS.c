

#include "PCUI_SSS.h"
#include "io.h"
#include <float.h>
#include <math.h>

#define _MAXCHAR 500


void EMOPCUI_allocate(EMOPCUI *pcui, int wpcQI, char *utl_name, int N){
	pcui->wpcQI = wpcQI;
	if((pcui->C = (double *) malloc(N * sizeof(double))) == NULL){
		printf("Error, not enough memory in SSS\n");
		exit(-1);
	}

	UTILITY_alloc(&pcui->utl, utl_name, 2);	
	/*int i;
	for(i = 0; i < 2; i++)
		pcui->w[i] = 0.5; // Same weight for all indicators -> search tradeoff*/
	pcui->w[0] = 0.01;
	pcui->w[1] = 0.99;
	
}

void EMOPCUI_free(EMOPCUI *pcui){	
	free(pcui->C);	
	UTILITY_free(&pcui->utl);
}





