#include "population.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>


void Population_allocate(Population *pop, int psize, int nvar, int nobj){
	if((pop->x = (double *) malloc(psize * nvar * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((pop->F = (double *) malloc(psize * nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((pop->Fnorm = (double *) malloc(psize * nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((pop->dummy = (double *) malloc(nvar * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}
}

void Population_free(Population *pop){
	free(pop->x);
	free(pop->F);
	free(pop->Fnorm);
	free(pop->dummy);
}

void Population_init(Population *pop, EMO_Rand *rand, int psize, int nvar, double *xmin, double *xmax){
	int i, j;

	for(i = 0; i < psize; i++){
		for(j = 0; j < nvar; j++){
			pop->x[i * nvar + j] = EMO_Rand_real1(rand, xmin[j], xmax[j]);
		}
	}
}

void Population_normalize(Population *pop, int psize, double *zmin, double *zmax, int nobj){
	int i, j;
	for(i = 0; i < psize; i++){
		for(j = 0; j < nobj; j++){
			pop->Fnorm[i * nobj + j] = (pop->F[i * nobj + j] - zmin[j]) / (zmax[j] - zmin[j]);
		}
	}
}


void Population_get_nadir(Population *pop, int psize, double *znad, int nobj){
	int i, j;
	for(i = 0; i < nobj; i++){
		znad[i] = -DBL_MAX;
	}

	for(i = 0; i < psize; i++){
		for(j = 0; j < nobj; j++){
			if(pop->F[i * nobj + j] > znad[j]){
				znad[j] = pop->F[i * nobj + j];
			}
		}
	}
}

void Population_get_ideal(Population *pop, int psize, double *zideal, int nobj){
	int i, j;
	for(i = 0; i < nobj; i++){
		zideal[i] = DBL_MAX;
	}

	for(i = 0; i < psize; i++){
		for(j = 0; j < nobj; j++){
			if(pop->F[i * nobj + j] < zideal[j]){
				zideal[j] = pop->F[i * nobj + j];
			}
		}
	}
}