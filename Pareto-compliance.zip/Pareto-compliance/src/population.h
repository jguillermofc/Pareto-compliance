#ifndef _POPULATION_H_
#define _POPULATION_H_


#include "Rand.h"

typedef struct{
	double *x;					// Vector of decision variables.
	double *F;					// Vector of objective functions.
	double *Fnorm;				// Vector of normalized objective functions.
	int psize;
	double *dummy;
}Population;

void Population_allocate(Population *, int, int, int);
void Population_free(Population *);
void Population_init(Population *, EMO_Rand *, int, int, double *, double *);
void Population_get_nadir(Population *, int, double *, int);
void Population_get_ideal(Population *, int, double *, int);
void Population_normalize(Population *, int, double *, double *, int);


#endif