
#ifndef __OBJECTIVE_FUNCTIONS_H__
#define __OBJECTIVE_FUNCTIONS_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>


#include "WFG.h"
#include "lame.h"

void findfunc(char *nom, void (**apf)(double *, double *, int, int, int *));

void ZDT1(double *x, double *F, int n, int k, int *feval);
void ZDT2(double *x, double *F, int n, int k, int *feval);
void ZDT3(double *x, double *F, int n, int k, int *feval);
void ZDT4(double *x, double *F, int n, int k, int *feval);
void ZDT6(double *x, double *F, int n, int k, int *feval);
void DTLZ1(double *x, double *F, int n, int k, int *feval);
void DTLZ2(double *x, double *F, int n, int k, int *feval);
void DTLZ3(double *x, double *F, int n, int k, int *feval);
void DTLZ4(double *x, double *F, int n, int k, int *feval);
void DTLZ5(double *x, double *F, int n, int k, int *feval);
void DTLZ6(double *x, double *F, int n, int k, int *feval);
void DTLZ7(double *x, double *F, int n, int k, int *feval);

void DTLZ1_MINUS(double *x, double *F, int n, int k, int *feval);
void DTLZ2_MINUS(double *x, double *F, int n, int k, int *feval);
void DTLZ3_MINUS(double *x, double *F, int n, int k, int *feval);
void DTLZ4_MINUS(double *x, double *F, int n, int k, int *feval);
void DTLZ5_MINUS(double *x, double *F, int n, int k, int *feval);
void DTLZ6_MINUS(double *x, double *F, int n, int k, int *feval);
void DTLZ7_MINUS(double *x, double *F, int n, int k, int *feval);

void VIE1(double *x, double *F, int n, int k, int *feval);
void VIE2(double *x, double *F, int n, int k, int *feval);
void VIE3(double *x, double *F, int n, int k, int *feval);

void UF1(double *x, double *F, int n, int k, int *feval);
void UF2(double *x, double *F, int n, int k, int *feval);
void UF3(double *x, double *F, int n, int k, int *feval);
void UF4(double *x, double *F, int n, int k, int *feval);
void UF5(double *x, double *F, int n, int k, int *feval);
void UF6(double *x, double *F, int n, int k, int *feval);
void UF7(double *x, double *F, int n, int k, int *feval);
void UF8(double *x, double *F, int n, int k, int *feval);
void UF9(double *x, double *F, int n, int k, int *feval);
void UF10(double *x, double *F, int n, int k, int *feval);

void defaultVariables(char *name, int nobj, int *nvar);
void defaultBoxConstraints(char *name, double *xmin, double *xmax, int nvar, int nobj);
#endif