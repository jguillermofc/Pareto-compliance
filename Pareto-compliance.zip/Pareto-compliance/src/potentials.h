#ifndef _POTENTIALS_H
#define _POTENTIALS_H


typedef struct
{
	double s;
	double *cpp;
	double *memoization;
	double (*pp)(double *x, double *y, double s, int dim);
	char pname[10];
}PP_contribution;

void EMO_PP_allocate(PP_contribution *ppc, int n);
void EMO_PP_free(PP_contribution *ppc);

void EMO_PP_greedySelection(double *F, int *filter, int csize, int dsize, int nobj, PP_contribution *ppc, double (*pp)(double *, double *, double, int));
void EMO_PP_contribution(double Es, int *filter, int n, PP_contribution *ppc);
double EMO_PP_update(double *cpp, int *filter, int n, int deleted);
double EMO_PP_matrix_computation(double *f,  int *filter, int n, int dim, PP_contribution *ppc, double (*pp)(double *, double *, double, int));


typedef double (*EMO_PairPotentialFunction)(double *x, double *y, double s, int dim);
double RSE(double *x, double *y, double s, int dim);
double COU(double *x, double *y, double s, int dim);
double GAE(double *x, double *y, double s, int dim);
double COU(double *x, double *y, double s, int dim);
double PT(double *x, double *y, double s, int dim);
double MPT(double *x, double *y, double s, int dim);
double GPT(double *x, double *y, double s, int dim);
double KRA(double *x, double *y, double s, int dim);

#endif