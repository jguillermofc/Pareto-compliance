#include "mop.h"
#include "ObjectiveFunctions.h"
#include "Parameter.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void MOP_allocate(MOP *mop, char *mop_name){
	// Associate mop name
	mop->mop_name = mop_name;
	// Set number of function evaluations to zero
	mop->feval = 0;
	// Find function
	findfunc(mop->mop_name, &mop->F); 
	// Reading parameters
	getInt("nobj", &mop->nobj);
	if(strncmp(mop->mop_name, "WFG", 3) == 0){
		getInt("wfg_nvar", &mop->nvar);
		getInt("wfg_npos", &mop->k_wfg);
	}else{
		getInt("nvar", &mop->nvar);
		if(mop->nvar == 0)
			defaultVariables(mop->mop_name, mop->nobj, &mop->nvar);
	}
	// Initializing WFG bechmark if necessary
	if(strncmp(mop->mop_name, "WFG", 3) == 0){	
		init_WFG(mop->mop_name[3] - '0', mop->nobj, mop->nvar, mop->k_wfg);
	}
	// Allocating memory for xmin and xmax vectors
	if((mop->xmin = (double *) malloc(mop->nvar * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((mop->xmax = (double *) malloc(mop->nvar * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if(strcmp(mop_name, "LAME") == 0 || strcmp(mop_name, "MIRROR") == 0){
		mop->isLame = 1;
		getInt("lame_difficulty", &mop->lame_difficulty);
		getDouble("lame_gamma", &mop->gamma_value);
		LS_init(mop->lame_difficulty, mop->gamma_value);
	}
	// Set the default box constraints
	defaultBoxConstraints(mop_name, mop->xmin, mop->xmax, mop->nvar, mop->nobj);
}

void MOP_free(MOP *mop){
	free(mop->xmin);
	free(mop->xmax);
	if(strncmp(mop->mop_name, "WFG", 3) == 0)
		free_WFG();
}

void MOP_evaluate(MOP *mop, double *x, double *F, int index){
	mop->F(&x[index * mop->nvar], &F[index * mop->nobj], mop->nvar, mop->nobj, &mop->feval);
}