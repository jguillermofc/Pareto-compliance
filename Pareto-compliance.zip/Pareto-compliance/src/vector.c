#include "vector.h"


double minkowski_distance(double *x, double *y, int dim, double p){
  int i;
  double s = 0.0;
  for(i = 0; i < dim; i++)
      s += pow(fabs(x[i] - y[i]), p);
  s = pow(s , 1.0 / p);
  return s;
}

double euclideanDistance(double *x, double *y, int dim){
	int i;
	double dist = 0.0;
	for(i = 0; i < dim; i++)
		dist += pow(x[i] - y[i], 2.0);
	dist = sqrt(dist);
	return dist;
}

double euclideanNorm(double *x, int dim){
	int i;
	double norm = 0.0;
	for(i = 0; i < dim; i++)
		norm += pow(x[i], 2.0);
	norm = sqrt(norm);
	return norm;
}

void scalarTimesVector(double *x, double r, int dim){
	int i;
	for(i = 0; i < dim; i++)
		x[i] *= r;
}

double innerProduct(double *x, double *y, int dim){
	int i;
	double r = 0.0;
	for(i = 0; i < dim; i++)
		r += x[i]*y[i];
	return r;
}

// r = x - y, i.e., r[i] = x[i] - y[i], i=1,...,dim
void vectorDifference(double *x, double *y, double *r, int dim){
	int i;
	for(i = 0; i < dim; i++)
		r[i] = x[i] - y[i];
}

void vectorTimesMatrix(double *A, double *x, double *b,  int dim){
	int i, j;
	double aux;
	for(i = 0; i < dim; i++){
		aux = 0.0;
		for(j = 0; j < dim; j++)
			aux += b[j] * A[j * dim + i];
		x[i] = aux;
	}
}