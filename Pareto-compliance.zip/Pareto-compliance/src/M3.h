#ifndef __M3_H__
#define __M3_H__



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


typedef struct{
	int *Min;
	int TopMin;
	int *rank;
	int numFronts;
	int *NDFront;
	int *sizeNDFront;
}M3NDsorting;

void M3_alloc(M3NDsorting *, int);
void M3_free(M3NDsorting *);
void moveToFront(int *T, int j, int size);
void shift(int *T, int j, int size);
void M3(M3NDsorting *m3nd, double *S, int *filter, int N, int dim, int start);
void M3NDsorting_execute(M3NDsorting *m3nd, double *S, int *filter, int N, int dim);
int ParetoDominance(double *, double *, int);

#endif

