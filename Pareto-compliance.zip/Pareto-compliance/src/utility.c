#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "vector.h"
#include "utility.h"

const char *Utility_list[] = {
	"asf",
	"aasf",
	"ewc",
	"vads",
	"ipbi",
	"atch",
	"wn",
	"ws"	
};

const UtilityFunction fdic[] = {
	asf,
	aasf, 
	ewc,
	vads,
	ipbi,
	atch,
	wn,
	ws
};


void UTILITY_alloc(UTILITY *util, char *str, int dim){
	int i;
	util->nobj = dim;
	util->alpha = 10e-4;
	util->p_ewc = 10;
	util->p_vads = 100;
	util->theta_ipbi = 5;
	util->atch_alpha = 0.1;
	

	if((util->z = (double *) malloc(dim * sizeof(double))) == NULL){
		printf("Error,not enough memory in MIHPS for reference point\n");
		exit(-1);	
	}

	if((util->znad = (double *) malloc(dim * sizeof(double))) == NULL){
		printf("Error, not enough memory in MIHPS for reference point\n");
		exit(-1);
	}

	if((util->vprime = (double *) malloc(dim * sizeof(double))) == NULL){
		printf("Error,not enough memory in MIHPS for vprime\n");
		exit(-1);	
	}

	if((util->wprime = (double *) malloc(dim * sizeof(double))) == NULL){
		printf("Error,not enough memory in MIHPS for wprime\n");
		exit(-1);	
	}

	i = UTILITY_find(Utility_list, str);
	util->uf = fdic[i];
}

void UTILITY_free(UTILITY *util){
	free(util->z);
	free(util->znad);
	free(util->vprime);
	free(util->wprime);
}

int UTILITY_find(const char *dicc[], char *pattern) {
  int i = 0;

  while(dicc[i] != NULL) {
    if(strcmp(pattern, dicc[i]) == 0) {
      return i;
    }
    i++;
  }

  return -1;
}


double asf(UTILITY *util, double *v, double *w){
	int i;
	double max = -DBL_MAX, aux;
	for(i = 0; i < util->nobj; i++){	
		aux = fabs(v[i]- util->z[i])/w[i];
		if(aux > max)
			max = aux;		
	}
	return max;
}

double aasf(UTILITY *util, double *v, double *w){
	int i;
	double max, sum = 0.0;
	max = asf(util, v, w);
	for(i = 0; i < util->nobj; i++)
		sum += (v[i] - util->z[i])/w[i];
	sum *= util->alpha;
	return max + sum;
}

double ewc(UTILITY *util, double *v, double *w){
	int i;
	double ewc = 0.0;
	for(i = 0; i < util->nobj; i++)
		ewc += (exp(util->p_ewc * w[i]) - 1.0) * exp(util->p_ewc * (v[i] - util->z[i]));
	return ewc;
}


double vads(UTILITY *util, double *v, double *w){
	int i;
	double vprime_norm, w_norm, vads;
	for(i = 0; i < util->nobj; i++){
		util->vprime[i] = v[i] - util->z[i];
		util->wprime[i] = w[i];
	}
	vprime_norm = euclideanNorm(util->vprime, util->nobj);
	w_norm = euclideanNorm(w, util->nobj);

	scalarTimesVector(util->wprime, 1.0 / w_norm, util->nobj);
	scalarTimesVector(util->vprime, 1.0 / vprime_norm, util->nobj);

	vads =  vprime_norm / pow(innerProduct(util->vprime, util->wprime, util->nobj), util->p_vads);

	return vads;
}

double ipbi(UTILITY *util, double *v, double *w){
	double d2, d1, w_norm;
	int i;
	for(i = 0; i < util->nobj; i++){
		util->vprime[i] = util->znad[i] - v[i];
		util->wprime[i] = w[i];
	}
	w_norm = euclideanNorm(w, util->nobj);

	scalarTimesVector(util->wprime, 1.0 / w_norm, util->nobj);

	d1 = fabs(innerProduct(util->vprime, util->wprime, util->nobj));
	scalarTimesVector(util->wprime, d1, util->nobj);
	vectorDifference(util->vprime, util->wprime, util->vprime, util->nobj);
	d2 = euclideanNorm(util->vprime, util->nobj);

	return util->theta_ipbi * d2 - d1;	 
}	



// Augmented weighted Tchebycheff metric
// utopian reference point
// Steuer 1986, Steuer and Choo (1983)
// Miettinen99, p. 101
// MODIFIED TO BE ORDER-PRESERVING
double atch(UTILITY *u, double *x, double *w) {
  	double t, s, vmax;
  	int i;

  	s = 0;
  	vmax = -DBL_MAX;

  	for(i = u->nobj - 1; i > -1; i--) {
    	t = w[i] * x[i];
    	s += x[i];
 
    	if(t > vmax)
      		vmax = t;
  	}

  	return vmax + u->atch_alpha * s;
}

double wn(UTILITY *u, double *x, double *w) {
  double t = 0;
  int i;

  for(i = u->nobj - 1; i > -1; i--){
    t += w[i] * pow(x[i], 3); // p = 3
   }

    t = cbrt(t);
  return t;
}

// Gass and Saaty (1995), Zadeh (1963)
// Miettinen99, p 78
// wi >= 0, sum wi = 1
// x = fi-z* 
double ws(UTILITY *u, double *x, double *w) {
  double t = 0;
  int i;

  for(i = u->nobj - 1; i > -1; i--)
    t += w[i] * x[i];
  return t;
}

