
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "ib_moea.h"
#include "population.h"
#include "mop.h"
#include "Parameter.h"
#include "Monitor.h"

IB_MOEA ibmoea;
MOP mop;
Population pop;
MONITOR monitor;


int main(int argc, char *argv[]){	
	int Executions, exec;
	char *param_name, *mop_name, *QI;
	if(argc != 5){
		printf("Syntax error! %s Parameter_file Problem Executions QI\n", argv[0]);
		printf("\tFor QI you can choose:\n");
		printf("\tPareto-compliant QIs:\n");
		printf("\t\tHV:		SMS-EMOA\n");	
		printf("\t\tIGD++:	Pareto-compliant IGD+	ATCH(IGD+, HV)\n");	
		printf("\tWeakly Pareto-compliant QIs:\n");
		printf("\t\tIGD+: 	IGD+-MaOEA\n");	
		printf("\tNot Pareto-compliant QIs:\n");	
		printf("\t\tIGD:		IGD-MaOEA\n");
		printf("\t\tGD:		GD-MaOEA\n");		
		exit(1);
	}
	// Read input parameters
	param_name = argv[1];
	mop_name = argv[2];
	Executions = atoi(argv[3]);
	QI = argv[4];


	// Read global parameters
	read_param(param_name);
	// Allocate memory for MOP structure
	MOP_allocate(&mop, mop_name);
	// Allocate memory for IB-MOEA structure
	IB_MOEA_allocate(&ibmoea, mop.nvar, mop.nobj, QI, param_name);
	// Allocate memory for population structure
	Population_allocate(&pop, ibmoea.N, mop.nvar, mop.nobj);
	// Allocate memory for monitor structure
	MONITOR_allocate(&monitor, mop.nobj, ibmoea.mu, ibmoea.maxFeval);
	MONITOR_set_reference_point(&monitor, mop_name, mop.nobj);
	// Free parameter structure
	free_param();

	// EXECUTE IB-MOEA
	for(exec = 1; exec <= Executions; exec++){
		MONITOR_initialize(&monitor);
		IB_MOEA_run(&ibmoea, &pop, &mop, exec, &monitor);
	}
	// Free monitor structure
	MONITOR_free(&monitor);
	// Free population structure
	Population_free(&pop);
	// Free IB-MOEA structure
	IB_MOEA_free(&ibmoea);
	// Free MOP structure
	MOP_free(&mop);
	return 0;
}
