
#include "Monitor.h"
#include "ib_moea.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>



void MONITOR_allocate(MONITOR *monitor, int nobj, int mu, int Gmax){
	monitor->freq = mu/2;
	monitor->samples_number = (Gmax - mu)/monitor->freq;
	monitor->counter = 0;

	EMO_HV_alloc(&monitor->hv, mu, nobj);

	if((monitor->zref = (double *) malloc(nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((monitor->fname = (char *) malloc(500 * sizeof(char))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}	

	if((monitor->hv_samples = (double *) malloc(monitor->samples_number * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}
	
	if((monitor->pd_samples = (double *) malloc(monitor->samples_number * sizeof(double))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((monitor->num_nondominated_solutions = (int *) malloc(monitor->samples_number * sizeof(int))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((monitor->activation_ib_de = (int *) malloc(monitor->samples_number * sizeof(int))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}

	if((monitor->num_layers = (int *) malloc(monitor->samples_number * sizeof(int))) == NULL){
		printf("Error, not enough memory!\n");
		exit(-1);
	}
	
}

void MONITOR_free(MONITOR *monitor){
	EMO_HV_free(&monitor->hv);
	free(monitor->zref);
	free(monitor->fname);	
	free(monitor->hv_samples);	
	free(monitor->pd_samples);
	free(monitor->num_nondominated_solutions);
	free(monitor->num_layers);
	free(monitor->activation_ib_de);		
}

void MONITOR_initialize(MONITOR *monitor){
	monitor->counter=0;
}

void MONITOR_adjust_counter(MONITOR *monitor, int generation){
	if(generation % monitor->freq == 0){
		monitor->counter++;
	}
}

void MONITOR_assessment(MONITOR *monitor, Population *pop, int mu, int nobj, int generation){
	if(generation % monitor->freq == 0){
		double r = EMO_HV_run(&monitor->hv, pop->F, NULL, mu, monitor->zref);
		monitor->hv_samples[monitor->counter] = r;		
		monitor->pd_samples[monitor->counter] = EMO_Indicator_PD(pop->F, mu, nobj);
	}		
}

void MONITOR_set_num_nondominated_solutions(MONITOR *monitor, int number, int generation){
	if(generation % monitor->freq == 0){
		monitor->num_nondominated_solutions[monitor->counter] = number;
	}
}

void MONITOR_set_activation(MONITOR *monitor, int wasActivated, int generation){
	if(generation % monitor->freq == 0){
		monitor->activation_ib_de[monitor->counter] = wasActivated;
	}
}

void MONITOR_set_num_layers(MONITOR *monitor, int number, int generation){
	if(generation % monitor->freq == 0){
		monitor->num_layers[monitor->counter] = number;
	}
}

void set_file_name(MONITOR *monitor, MOP *mop, int QIcode, int exec, char *ext){
	switch(QIcode){
		case HV:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/SMS-EMOA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
				sprintf(monitor->fname, "output/SMS-EMOA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case R2:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/R2-EMOA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/R2-EMOA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case IGDplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/IGD+-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/IGD+-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case EPSplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/EPS+-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/EPS+-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case DELTAp:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/DELTAp-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/DELTAp-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case IGD:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/IGD-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/IGD-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case GD:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/GD-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/GD-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case R2plusplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/R2++-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/R2++-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;

		case IGDplusplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/IGD++-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/IGD++-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;


		case EPSplusplus:
			if(!strcmp(mop->mop_name, "LAME") || !strcmp(mop->mop_name, "MIRROR"))
				sprintf(monitor->fname, "output/EPS++-MaOEA_%s_%.2f_d%d_%.2dD_R%.2d.%s", mop->mop_name, mop->gamma_value, mop->lame_difficulty, mop->nobj, exec, ext);
			else
			sprintf(monitor->fname, "output/EPS++-MaOEA_%s_%.2dD_R%.2d.%s", mop->mop_name, mop->nobj, exec, ext);
		break;
	}
}

void MONITOR_print_results(MONITOR *monitor, MOP *mop, int QIcode, int exec){
	FILE *file;
	int i;

	// Hypervolume convergence graph
	set_file_name(monitor, mop, QIcode, exec, "hv_conv");	
	if((file = fopen(monitor->fname, "w")) == NULL){
    	printf("Error, the file %s could not be opened\n", monitor->fname);
    	exit(1);
  	}  	
  	for(i = 0; i < monitor->samples_number; i++)
  		fprintf(file, "%.6lf\n", monitor->hv_samples[i]);
  	fclose(file);
	  	

  	// Pure Diversity graph
	set_file_name(monitor, mop, QIcode, exec, "pd_div");	
	if((file = fopen(monitor->fname, "w")) == NULL){
    	printf("Error, the file %s could not be opened\n", monitor->fname);
    	exit(1);
  	}  	
  	for(i = 0; i < monitor->samples_number; i++)
  		fprintf(file, "%.6lf\n", monitor->pd_samples[i]);
  	fclose(file);

  	// Graph of number of nondominated solutions per generation
	set_file_name(monitor, mop, QIcode, exec, "nondom");	
	if((file = fopen(monitor->fname, "w")) == NULL){
    	printf("Error, the file %s could not be opened\n", monitor->fname);
    	exit(1);
  	}  	
  	for(i = 0; i < monitor->samples_number; i++)
  		fprintf(file, "%d\n", monitor->num_nondominated_solutions[i]);
  	fclose(file);


  	// Graph of number of nondominated layers per generation
	set_file_name(monitor, mop, QIcode, exec, "num_layers");	
	if((file = fopen(monitor->fname, "w")) == NULL){
    	printf("Error, the file %s could not be opened\n", monitor->fname);
    	exit(1);
  	}  	
  	for(i = 0; i < monitor->samples_number; i++)
  		fprintf(file, "%d\n", monitor->num_layers[i]);
  	fclose(file);

  	// IB-DE activation graph
	set_file_name(monitor, mop, QIcode, exec, "activation");	
	if((file = fopen(monitor->fname, "w")) == NULL){
    	printf("Error, the file %s could not be opened\n", monitor->fname);
    	exit(1);
  	}  	
  	for(i = 0; i < monitor->samples_number; i++)
  		fprintf(file, "%d\n", monitor->activation_ib_de[i]);
  	fclose(file);  
}

void MONITOR_set_reference_point(MONITOR *monitor, char *mop_name, int nobj){
	int i;
	if(strcmp(mop_name, "DTLZ1") == 0){
		for(i = 0; i < nobj; i++)
			monitor->zref[i] = 1.0;
	}else if(strcmp(mop_name, "DTLZ2") == 0 
		|| strcmp(mop_name, "DTLZ3") == 0 
		|| strcmp(mop_name, "DTLZ4") == 0 
		|| strcmp(mop_name, "DTLZ5") == 0 
		|| strcmp(mop_name, "DTLZ6") == 0 
		|| strcmp(mop_name, "LAME") == 0 
		|| strcmp(mop_name, "MIRROR") == 0){
		for(i = 0; i < nobj; i++)
			monitor->zref[i] = 2.0;
	}else if(strcmp(mop_name, "DTLZ7") == 0){
		for(i = 0; i < nobj - 1; i++)
			monitor->zref[i] = 1.0;
		monitor->zref[nobj - 1] = 21.0;
	}else if(strcmp(mop_name, "WFG1") == 0 
		|| strcmp(mop_name, "WFG2") == 0 
		|| strcmp(mop_name, "WFG3") == 0 
		|| strcmp(mop_name, "WFG4") == 0 
		|| strcmp(mop_name, "WFG5") == 0 
		|| strcmp(mop_name, "WFG6") == 0 
		|| strcmp(mop_name, "WFG7") == 0 
		|| strcmp(mop_name, "WFG8") == 0 
		|| strcmp(mop_name, "WFG9") == 0){
		for(i = 0; i < nobj; i++)
			monitor->zref[i] = 2.0 * (i + 1) + 1;
	}else if((strncmp(mop_name, "WFG1", 4) == 0 
		|| strncmp(mop_name, "WFG2", 4) == 0 
		|| strncmp(mop_name, "WFG3", 4) == 0 
		|| strncmp(mop_name, "WFG4", 4) == 0 
		|| strncmp(mop_name, "WFG5", 4) == 0 
		|| strncmp(mop_name, "WFG6", 4) == 0 
		|| strncmp(mop_name, "WFG7", 4) == 0 
		|| strncmp(mop_name, "WFG8", 4) == 0 
		|| strncmp(mop_name, "WFG9", 4) == 0) && strlen(mop_name) == 8){
		for(i = 0; i < nobj; i++)
			monitor->zref[i] = 2.0 * (i + 1) + 1;
	}else if(strcmp(mop_name, "DTLZ1_MINUS") == 0 
		|| strcmp(mop_name, "DTLZ2_MINUS") == 0 
		|| strcmp(mop_name, "DTLZ3_MINUS") == 0 
		|| strcmp(mop_name, "DTLZ4_MINUS") == 0 
		|| strcmp(mop_name, "DTLZ5_MINUS") == 0 
		|| strcmp(mop_name, "DTLZ6_MINUS") == 0 
		|| strcmp(mop_name, "WFG1_MINUS") == 0 
		|| strcmp(mop_name, "WFG2_MINUS") == 0 
		|| strcmp(mop_name, "WFG3_MINUS") == 0
		|| strcmp(mop_name, "WFG4_MINUS") == 0
		|| strcmp(mop_name, "WFG5_MINUS") == 0
		|| strcmp(mop_name, "WFG6_MINUS") == 0
		|| strcmp(mop_name, "WFG7_MINUS") == 0
		|| strcmp(mop_name, "WFG8_MINUS") == 0
		|| strcmp(mop_name, "WFG9_MINUS") == 0){
		for(i = 0; i < nobj; i++)
			monitor->zref[i] = 0.1;
	}else if(strcmp(mop_name, "DTLZ7_MINUS") == 0){
		for(i = 0; i < nobj - 1; i++)
			monitor->zref[i] = 0.1;
		monitor->zref[nobj - 1] = -10.0;
	}else if(strcmp(mop_name, "VIE1") == 0){
		monitor->zref[0] = monitor->zref[2] = 5.0;
		monitor->zref[1] = 6.0;
	}else if(strcmp(mop_name, "VIE2") == 0){
		monitor->zref[0] = 5.0;
		monitor->zref[1] = -15.0;
		monitor->zref[2] = -11.0;
	}else if(strcmp(mop_name, "VIE3") == 0){
		monitor->zref[0] = 11.0;
		monitor->zref[1] = 19.0;
		monitor->zref[2] = 5.0;
	}
}









